<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<title>Results</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="autism ,free, open source, accessibility checker, accessibility reviewer, accessibility evaluator, accessibility evaluation, evaluate accessibility, test accessibility, review accessibility, STANCA." />
	<meta name="description" content="Web accessibility evalution tool to help developer and parents ensure Web content is accessible to people with autism." />
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/ac_out_style.css">
        <link rel="stylesheet" href="css/navbar.css">
        <script src="js/jquery.js" type="text/javascript"></script>
        <script src="js/checker.js" type="text/javascript"></script>
        <script src="js/done_js.js" type="text/javascript"></script>
<style>
.fixed {
  position: fixed;
  top:0; left:0;
  width: 100%;
}
</style>
</head>
<body class="Site" onload="srcFunction()">
    <header>
      <div class="home">
          <div id="colh_1" class="colh_1">

            <div class="home_1">
              <a href="index.php">
                <img src="images/logo_white2.png">
            </a>
          </div>
          <div class="home_sub_logo" id="home_sub_logo">webpages validator for autism</div>
          </div>
            <div id="colh_2" class="colh_2">
              <a href="help.php" target="_blank"> <img src="images/question-mar.png">  </a>
            </div>
      </div>
  </header> 
<section class="Site-content" style="background-color: #fff;" >
	<div class="center-input-form">
	<a name="report" title="Start Report"></a>
	<fieldset class="group_form"><legend class="group_form">Accessibility Review</legend>
	<h3>Accessibility Review (Guidelines: <a title="Stanca Act(link opens in a new window)" target="_new" href="https://achecker.ca/guideline/view_guideline.php?id=3">Stanca Act</a>)</h3>
	<div class="center">
		<form name="file_form" enctype="multipart/form-data" method="post">
		<fieldset id="report_file"><legend class="report_file">Export Report</legend>
			<div style="padding: 0.5em;">
				<label for="file_type">Export Format:</label>
				<select name="file_menu" id="fileselect">
					<option value="pdf" selected="selected">PDF</option>
					<option value="earl">EARL</option>
					<option value="csv">CSV</option>
					<option value="html">HTML</option>
				</select>&nbsp;&nbsp;&nbsp;&nbsp;
			
				&nbsp;&nbsp;<label for="problem_type">Report to Export:</label>
				<select name="problem_menu" id="problemselect">
					<option value="all" selected="selected">All</option>
					<option value="known">Known</option>
					<option value="likely">Likely</option>
					<option value="potential">Potential</option>
					<option value="html">HTML Validation</option>
					<option value="css">CSS Validation</option>
				</select>&nbsp;&nbsp;&nbsp;&nbsp;

				<iframe id="downloadFrame" src="" style="display:none;"></iframe>
				<input class="report_file_button" type="button" name="validate_export" id="validate_file_button" value="Get File" onclick="return AChecker.input.validateFile('spinner_export');">
				<div class="spinner_div">
					<img class="spinner_img" id="spinner_export" style="display:none" src="https://achecker.ca/themes/default/images/spinner.gif" alt="Accessibility Validation in Progress">
					&nbsp;
				</div>
			</div>
		</fieldset>
		</form>
	</div>

	<div class="topnavlistcontainer"><br>
		<ul class="navigation">
			<li class="navigation"><a href="javascript:void(0);" accesskey="1" title="Known Problems Alt+1" id="AC_menu_errors" onclick="AChecker.output.onClickTab('AC_errors');" class="active"><span class="nav">Known Problems(<span id="AC_num_of_errors">6</span>)</span></a></li>

			<li class="navigation"><a href="javascript:void(0);" accesskey="2" title="Likely Problems Alt+2" id="AC_menu_likely_problems" onclick="AChecker.output.onClickTab('AC_likely_problems');"><span class="nav">Likely Problems (<span id="AC_num_of_likely">22</span>)</span></a></li>

			<li class="navigation"><a href="javascript:void(0);" accesskey="3" title="Potential Problems Alt+3" id="AC_menu_potential_problems" onclick="AChecker.output.onClickTab('AC_potential_problems');"><span class="nav">Potential Problems (<span id="AC_num_of_potential">340</span>)</span></a></li>

			<li class="navigation"><a href="javascript:void(0);" accesskey="4" title="HTML Validation Alt+4" id="AC_menu_html_validation_result" onclick="AChecker.output.onClickTab('AC_html_validation_result');"><span class="nav">HTML Validation (<span id="AC_num_of_html_errors">0</span>)</span></a></li>

			<li class="navigation"><a href="javascript:void(0);" accesskey="5" title="CSS Validation Alt+5" id="AC_menu_css_validation_result" onclick="AChecker.output.onClickTab('AC_css_validation_result');"><span class="nav">CSS Validation (<span id="AC_num_of_css_errors">17</span>)</span></a></li>

			<li class="navigation"><a href="javascript:void(0);" accesskey="6" title="Autism Validation Alt+6" id="Autism_menu_errors" onclick="AChecker.output.onClickTab('Autism_result');"><span class="nav">Autism Validation (<span id="Autism_num_of_errors"></span>)</span></a></li>

			<li class="navigation"><a href="javascript:void(0);" accesskey="7" title="Autism Summary Alt+7" id="Summary_menu_errors" onclick="AChecker.output.onClickTab('Summary_result');"><span class="nav">Autism Summary</span></a></li>
		</ul>
	</div>
	<div id="AC_errors">
	</div>

	<div id="AC_likely_problems" style="display:none;">
	</div>
	<div id="AC_potential_problems" style="margin-top:1em; display:none;">
	</div>
	<div id="AC_html_validation_result" style="margin-top:1em; display:none;"></div>
	
<div id="Autism_result" class="autism" style="margin-top:1em; display:none;">
<p hidden>addhere</p>
</div>
<div id="Summary_result" class="sum_autism" style="margin-top:1em; display:none;">
<p hidden>add_summary_here</p>
 </div>
 <script>
         var container = document.querySelector("#table_sum");
         var divs1 = document.querySelector("#ok");
         var divs2 = document.querySelector("#notok");
         var trs = container.querySelectorAll('tr');
         var x = 0;
         var table = document.querySelector("#table_sum");
         var tds = table.querySelectorAll('td');
         for (i = 0; i < tds.length; i++) {
             var img = tds[i].getElementsByTagName("img")[0];
         	if(tds[i].contains(img)==true)
             	x=x+1;
        }
         if(x>0)
         {
             divs1.setAttribute("class", "classnotok");
             divs2.style['padding-left'] = '10px';
             divs2.style['padding-right'] = '10px';
         }
         else
         {
         	divs2.setAttribute("class", "classnotok");
             divs1.style['padding-left'] = '10px';
             divs1.style['padding-right'] = '10px';
         }
 
 </script>
</div>
	</fieldset>
</div>
</section>
<footer> 
          <div class="footer">
              <div class="footer_1">
                  CREATED BY: Margherita Rossi 
              </div>              
          </div>
    </footer>
    <script>
        var container = document.querySelector("#Autism_result");
        var trs = container.querySelectorAll('tr')
        var text = document.createTextNode(trs.length);
        var child = document.getElementById('Autism_num_of_errors');
        child.parentNode.insertBefore(text, child);
    </script>
        
</body>
</html>

