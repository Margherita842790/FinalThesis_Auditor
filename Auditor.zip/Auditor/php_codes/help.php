<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<title>Auditor - Help</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="autism ,free, open source, accessibility checker, accessibility reviewer, accessibility evaluator, accessibility evaluation, evaluate accessibility, test accessibility, review accessibility, STANCA." />
	<meta name="description" content="Web accessibility evalution tool to help developer and parents ensure Web content is accessible to people with autism." />
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/ac_out_style.css">
        <link rel="stylesheet" href="css/navbar.css">
        <script src="js/jquery.js" type="text/javascript"></script>
        <script src="js/checker.js" type="text/javascript"></script>
        <script src="js/done_js.js" type="text/javascript"></script>
<style>
.fixed {
  position: fixed;
  top:0; left:0;
  width: 100%;
}
img {
  max-width: 80%;
  height: auto;  
}
h4{
    font: normal 18px/1.5 "Fira Sans", "Helvetica Neue", sans-serif;
  color: #4db7b3;
  font-weight: 600;
  letter-spacing: .09em;
  text-transform: uppercase;
  padding: 2px;
  word-wrap: break-word;
     -webkit-hyphens: auto;
     -moz-hyphens: auto;
     -ms-hyphens: auto;
     -o-hyphens: auto;
     hyphens: auto;
}
table {
  font: normal 12px/1.5 arial, sans-serif;
  border: 1px solid #ccc;
  border-collapse: collapse;
  margin: 0;
  padding: 0;
  width: 100%;
  table-layout: fixed; 
}
th, td {
   padding: .625em;
  text-align: left;
  border: 1px solid #dddddd;
  word-wrap:break-word
}
tr{background-color: #f8f8f8;
  border: 1px solid #ddd;
  padding: .35em;}
</style>
</head>
<body class="Site" onload="srcFunction()">
    <header>
      <div class="home">
          <div id="colh_1" class="colh_1">

            <div class="home_1">
              <a href="index.php">
                <img src="images/logo_white2.png">
            </a>
          </div>
          <div class="home_sub_logo" id="home_sub_logo">webpages validator for autism</div>
          </div>
            <div id="colh_2" class="colh_2">
              <a href="help.php" target="_blank"> <img src="images/question-mar.png">  </a>
            </div>
      </div>
  </header>  
<section class="Site-content" style="background-color: #fff;" >         
<div id="help" style="text-align: justify; padding-left: 10px; padding-right: 10px; font-family: arial, sans-serif;">
<h1> Help </h1>
Welcome to Auditor validator. This tool checks if a provided url is accessible for people with Autism Spectrum Disorder 
by evaluating the guidelines provided by the Stanca Act and W3C.
It is based on <a href="https://achecker.ca/checker/index.php">Achecker</a> validator.<br>
In the first page you can find this form:
<div class="contain_images" style="margin: auto; width: 50%; padding: 10px; "><img src="images/index.png"></div>
Put the url you want to test and then choose between the <em><strong>I'm a normal user</strong></em>, mode which will lead to a summary page which is easy to read also for laymans, or <em><strong>I'm a programmer</strong></em> mode, which leads to a more detailed page.
<h4>I'm a normal user</h4>
When you choose <em><strong>I'm a normal user</strong></em> you are redirected to a summary page. This page shows an overview table where the presence of the error is represented with a red cross, while the absence with a green tick. It shows also the mean text-readability of the webpage, if it contains text.
<div class="contain_images" style="margin: auto; width: 50%; padding: 10px; width: 80%;"><img src="images/sum.PNG"></div>
<h4>I' m a programmer</h4>
When you choose <em><strong>I' m a programmer</strong></em> you are redirected to a detailed page where you can find a navbar like the following:
<div class="contain_images" style="margin: auto; width: 50%; padding: 10px; width: 100%;"><img src="images/navbar00.PNG"></div>
<br> The first 5 keys are taken from achecker's analysis:<br>
<div style="overflow-x:auto;">
  <table style="margin-top: 20px;">
    <tr>
        <td><strong>Known problems</strong></td>
      <td>These are problems that have been identified with certainty as accessibility barriers. You must modify your page to fix these problems.</td>  
    </tr>
    <tr>
      <td><strong>Likely problems</strong></td>
      <td>These are problems that have been identified as probable barriers, but require a human to make a decision. You will likely need to modify your page to fix these problems.</td>    
    </tr>
    <tr>
      <td><strong>Potential problems</strong></td>
      <td>These are problems that AChecker cannot identify, that require a human decision. You may have to modify your page for these problems, but in many cases you will just need to confirm that the problem described is not present.</td>
    </tr>
    <tr>
      <td><strong>HTML Validation</strong></td>
      <td>These are html problems </td>
    </tr>
    <tr>
      <td><strong>CSS Validation</strong></td>
      <td>These are css problems </td>
    </tr>
  </table>
</div>
<br>
The last 2 are specific for people with autism:
<div style="overflow-x:auto;">
    <table style="margin-bottom: 20px;margin-top: 20px;">
    <tr>
      <td><strong>Autism Validation</strong></td>
      <td>shows if the url provided contains animated images, too complex texts and their analysis, images with text inside them, colors which are not good for people with ASD.</td>  
    </tr>
    <tr>
      <td><strong>Autism Summary</strong></td>
      <td>this shows the same overview table of the I'm a normal user's mode.</td>    
    </tr>
  </table>
</div>
</div>
</section>
<footer> 
          <div class="footer">
              <div class="footer_1">
                  CREATED BY: Margherita Rossi 
              </div>              
          </div>
    </footer>       
</body>
</html>

