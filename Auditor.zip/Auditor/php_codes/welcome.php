<?php
ob_start();
$url = $_POST["site"];
$protocol = "https://";
$p2 = "http";

$isthere=preg_match("/{$p2}/i", $url);
if($isthere === 0){
  $url = $protocol.$url;
}

$path="pyt";
$dir = chdir($path); 
list($scriptPath) = get_included_files();
$headers = @get_headers($url, 1);
if (! @(file_get_contents($url))) {
    echo "0";
} 
else {
       exec("./auditor/env/bin/python3 main.py '$scriptPath' '$url'");
       if(isset($_POST['usprog'])){
        if($_POST['usprog']=="normal")
        { 
           echo "2";
        }    
        else
        {
           echo "3";
        }
     }
}

?>

