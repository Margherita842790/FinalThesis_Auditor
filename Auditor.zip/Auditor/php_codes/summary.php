<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<title>Summary</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="autism ,free, open source, accessibility checker, accessibility reviewer, accessibility evaluator, accessibility evaluation, evaluate accessibility, test accessibility, review accessibility, STANCA." />
	<meta name="description" content="Web accessibility evalution tool to help developer and parents ensure Web content is accessible to people with autism." />
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/ac_out_style.css">
        <link rel="stylesheet" href="css/navbar.css">
        <script src="js/jquery.js" type="text/javascript"></script>
        <script src="js/checker.js" type="text/javascript"></script>
        <script src="js/done_js.js" type="text/javascript"></script>
<style>
.fixed {
  position: fixed;
  top:0; left:0;
  width: 100%;
}
</style>
</head>
<body class="Site" onload="srcFunction()">
    <header>
      <div class="home">
          <div id="colh_1" class="colh_1">

            <div class="home_1">
              <a href="index.php">
                <img src="images/logo_white2.png">
            </a>
          </div>
          <div class="home_sub_logo" id="home_sub_logo">webpages validator for autism</div
          </div>
            <div id="colh_2" class="colh_2">
              <a href="help.php" target="_blank"> <img src="images/question-mar.png">  </a>
            </div>
      </div>
  </header>
<section class="Site-content" style="background-color: #fff;" >
<style>
#ok {
text-align: center;
position: absolute;
  margin: auto;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  width: 50%;
  height: 50%;
}
#notok table {
  font-family: arial, sans-serif;
  border: 1px solid #ccc;
  border-collapse: collapse;
  margin: 0;
  padding: 0;
  width: 100%;
  table-layout: fixed;
}
#notok table tr{
  background-color: #f8f8f8;
  border: 1px solid #ddd;
  padding: .35em;
}
#notok table th{
  padding: .625em;
  text-align: center;
  border: 1px solid #dddddd;
  word-wrap:break-word
}
#notok table td{
  padding: .625em;
  text-align: left;
  border: 1px solid #dddddd;
  word-wrap:break-word
}
#notok td img{
    display: block;
    margin-left: auto;
    margin-right: auto;
}
#notok table th{
  font-size: .85em;
  letter-spacing: .1em;
  text-transform: uppercase;
}
.classok {
  padding: 20px;
}
.classnotok{
	display: none;
}
.legendtable {
    width: 100%;
    padding: 10px;
    overflow: hidden;
}
.legendtable img {
    margin-right: 15px;
    float: left;
}
</style>
<div id="ok">
<h1> Congratulations! </h1>
<p> The site at the provided url is accessible for people with ASD </p>
</div>
<div id="notok">
<h2> Sorry! </h2>
<p> Something at the provided url is not accessible for people with disabilities, expecially for people with ASD </p>
<form style="padding: 10px;">
 <fieldset style="font-family: arial, sans-serif;">
  <legend>How to read the table</legend>
  <div class="legendtable">
   <img src="images/error.png" alt="redcross" height="32" width="32">
    <p>Stands for "error found"</p>
</div>
<div class="legendtable">
   <img src="images/green_tick.png" alt="greentick" height="32" width="32">
    <p>Stands for "ok, error not found"</p>
</div>
 </fieldset>
</form>
<br><br>
<table id="table_sum">
  <thead>
    <tr>
      <th scope="col">Issue</th>
      <th scope="col">Presence</th>
      <th scope="col">In particular</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Text Difficulties</td>
		<td> <img src="images/error.png" alt="TxtD" height="12" width="12"></td>
      <td></td>
    </tr>
    <tr>
      <td>Overall Text readability</td>
		<td> <img src="images/error.png" alt="TxtC" height="12" width="12"></td>
		<td>Readability reached: 95.32% </td>
    </tr>
    <tr>
      <td>Presence of text in images</td>
		<td> <img src="images/green_tick.png" alt="Tinimg" height="12" width="12"></td>
		<td></td>
    </tr>
     <tr>
      <td>Presence of animated images</td>
		<td> <img src="images/green_tick.png" alt="gifs" height="12" width="12"></td>
		<td></td>
    </tr>
    <tr>
      <td>Colors difficulties in page elements</td>
		<td> <img src="images/error.png" alt="coldiff" height="12" width="12"></td>
		<td>Colors: <span style="margin-right:10px">header: #ac0033</span><div class="circle" style="background:#ac0033;"></div> <span style="margin-right:10px">div: #ac0033</span><div class="circle" style="background:#ac0033;"></div> <span style="margin-right:10px">a: #d9534f</span><div class="circle" style="background:#d9534f;"></div> <span style="margin-right:10px">span: #ac0033</span><div class="circle" style="background:#ac0033;"></div> <span style="margin-right:10px">small: #ac0033</span><div class="circle" style="background:#ac0033;"></div> <span style="margin-right:10px">br: #ac0033</span><div class="circle" style="background:#ac0033;"></div> <span style="margin-right:10px">https://www.unive.it//pag/templates/img/logo_uni/CF_moeca_pos_124.png #a21b3b</span><div class="circle" style="background:#a21b3b;"></div></td>
<td></td>
	</tr>
  </tbody>
</table>
</div>
<script>
        var container = document.querySelector("#table_sum");
        var divs1 = document.querySelector("#ok");
        var divs2 = document.querySelector("#notok");
        var trs = container.querySelectorAll('tr');
        var x = 0;
        var table = document.querySelector("#table_sum");
        var tds = table.querySelectorAll('td');
        for (i = 0; i < tds.length; i++) {
            var img = tds[i].getElementsByTagName("img")[0];
        	if(tds[i].contains(img)==true)
            	x=x+1;
       }
       if(x>0)
        {
            divs1.setAttribute("class", "classnotok");
            divs2.style['padding-left'] = '10px';
            divs2.style['padding-right'] = '10px';
        }
        else
        {
        	divs2.setAttribute("class", "classnotok");
            divs1.style['padding-left'] = '10px';
            divs1.style['padding-right'] = '10px';
        }
</script>
</section>
<footer>
          <div class="footer">
              <div class="footer_1">
                  CREATED BY: Margherita Rossi
              </div>
          </div>
    </footer>
</body>
</html>

