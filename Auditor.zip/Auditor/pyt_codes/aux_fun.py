from urllib.request import urlopen
from textblob import TextBlob
import re
from PIL import Image
import scipy
import scipy.misc
import scipy.cluster
import requests
from io import BytesIO
import math as m
import numpy as np
import imghdr
import urllib
import base64
from itertools import groupby

def find_line(file_path, lookup):
    aux = []
    with open(file_path, encoding="utf8") as myFile:
        for num, line in enumerate(myFile, 1):
            if lookup in line:
                if lookup == '</fieldset>':
                    aux.append(num - 1)
                else:
                    aux.append(num)
    return aux

def copyrows(file_from, file_to):
    line_start = find_line(file_from, '<section class="Site-content" style="background-color: #fff;" >')[0]
    line_end = find_line(file_from, '</script>')[3]
    lineno = find_line(file_to, '<p hidden>add_summary_here</p>')[0]
    list_beg = range(line_start, line_end)
    val = 'var container = document.querySelector("#table_sum");'
    x = ''
    with open(file_from, "r") as file:
        for i, line in enumerate(file):
            if i in list_beg:
               x = x+' '+line
    put(file_to, lineno, val, x)
    return


def put(file_path, line_number, value, ins_val):
    with open(file_path, encoding="utf8") as myfile:
        if value not in myfile.read():
            with open(file_path, mode="r", encoding="utf8") as f:
                contents = f.readlines()
                f.close()
                contents.insert(line_number, ins_val)
                with open(file_path, mode="w", encoding="utf8") as f:
                    contents = "".join(contents)
                    f.write(contents)
                    f.close()
    return

def find_and_put(file_path, lookup, value, ins_val):
    aux = find_line(file_path, lookup)
    if lookup == '</fieldset>':
        aux = aux[1]
    else:
        aux = aux[0]
    with open(file_path, encoding='utf-8') as myfile:
        if value not in myfile.read():
            with open(file_path, mode="r", encoding='utf-8') as f:
                contents = f.readlines()
                f.close()
                contents.insert(aux, ins_val)
                with open(file_path, mode="w", encoding="utf8") as f:
                    contents = "".join(contents)
                    f.write(contents)
                    f.close()
    return

def find_language(site_url, soup):
    start = '<title>'
    end = '</title>'
    title = soup[soup.find(start) + len(start):soup.rfind(end)]
    language = TextBlob(title)
    lang=language.detect_language()
    return lang


############### colors ##############
def is_image(url):
    if 'linear-gradient' not in url:
        req = urllib.request.Request(url, headers={'User-Agent': "Magic Browser"})
        data = urllib.request.urlopen(req).read()
        image_type = imghdr.what(None, data)
        if not image_type:
            return False
        else:
            return True
    else:
        return False

def is_grey_scale(img_path):
    img = Image.open(img_path)
    if img.mode == "RGBA" or "transparency" in img.info:
        img = img.convert('RGBA')
    else:
        img = img.convert('RGB')
    w,h = img.size
    for i in range(w):
        for j in range(h):
            r,g,b = img.getpixel((i,j))
            if r != g != b: return False
    return True

def rgb2hex(rgb):
    r = rgb[0]
    g = rgb[1]
    b = rgb[2]
    hexColour ='#%02x%02x%02x' % (r, g, b)
    return hexColour

def rgb2hsv(rgb):
    r= rgb[0]
    g= rgb[1]
    b = rgb[2]
    if len(rgb) > 3:
        alfa = rgb[3]
    else:
        alfa=1
    r, g, b = r/255.0, g/255.0, b/255.0
    mx = max(r, g, b)
    mn = min(r, g, b)
    df = mx-mn
    if mx == mn:
        h = 0
    elif mx == r:
        h = (60 * ((g-b)/df) + 360) % 360
    elif mx == g:
        h = (60 * ((b-r)/df) + 120) % 360
    elif mx == b:
        h = (60 * ((r-g)/df) + 240) % 360
    if mx == 0:
        s = 0
    else:
        s = df/mx
    v = mx
    return h, s, v, alfa

def image_proc(url):
    num_clusters = 5
    rgb = []
    if 'htt' in url and '.svg' in url:
        response = str(requests.get(url).content)
        result = re.findall(r'fill.*#.{6}', response)
        new_col_svg = []
        for i in result:
            i = re.sub(r'.*#', '', i)
            i = '#' + i
            new_col_svg.append(i)
        duplicates = [len(list(group)) for key, group in groupby(new_col_svg)]
        new_col_svg = list(dict.fromkeys(new_col_svg))
        rgbs = []
        for x in new_col_svg:
            h = x.lstrip('#')
            rgb1 = list(int(h[i:i + 2], 16) for i in (0, 2, 4))
            rgbs.append(rgb1)
        lun_duplic = len(duplicates)
        if(lun_duplic!=0):
            predominant = duplicates.index(max(duplicates))
            rgb=rgbs[predominant]
    else:
        if 'data:im' in url:
            url= re.sub(r'[^,]*,', '', url)
            url = url.replace(' ', '+')
            im = Image.open(BytesIO(base64.b64decode(url)))
        else:
            response = requests.get(url)
            im = Image.open(BytesIO(response.content))
            if '.png' in url:
                im = im.convert('RGB')
        im = im.resize((150, 150))
        ar = np.asarray(im)
        shape = ar.shape
        lun_shape=len(shape)
        if lun_shape==3:
            ar = ar.reshape(scipy.product(shape[:2]), shape[2]).astype(float)
            codes, dist = scipy.cluster.vq.kmeans(ar, num_clusters)
            vecs, dist = scipy.cluster.vq.vq(ar, codes)  # assign codes
            counts, bins = scipy.histogram(vecs, len(codes))  # count occurrences
            index_max = scipy.argmax(counts)  # find most frequent
            codes = codes.tolist()
            peak = codes[index_max]
            for x in peak:
                rgb.append(m.ceil(x))
    return rgb

def black_grey_white(rgb, hsv):
    r = rgb[0]
    g = rgb[1]
    b = rgb[2]
    v = hsv[2] * 100
    if r == g and g == b:
        return True
    else:
        if v <= 20:
            return True
        else:
            return False

def clean_colors (item):
    result = item.split(")")
    result = [re.sub(r'[^0-9^,]', '', w) for w in result]
    result = [x for x in result if x.strip()]
    res = []
    for j in result:
        j = [int(x) for x in j.split(',') if x.strip().isdigit()]
        if len(j) > 3:
            del j[-1]
        res.append(j)
    flattened = [val for sublist in res for val in sublist]
    return flattened

def clean_img(item):
    if "url" in item:
        item = re.sub(r'url\("', '', item)
        item = re.sub(r'"\)', '', item)
    return item

def thresholds(h, s):
    s=s*100
    if s < 50:
        return True
    else:
        if(s < 70) and (10 <= h and h <= 45):
            return True
        else:
            if 80<=h and h<=285:
                return True
            else:
                return False

def unique_list(l):
    ulist = []
    [ulist.append(x) for x in l if x not in ulist]
    return ulist



