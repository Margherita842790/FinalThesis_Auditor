import autism.ckr as ck
import autism.aut_fun as at
import autism.aux_fun as ax
from multiprocessing import Pool
import os.path
import sys

if __name__ == '__main__':
    location = sys.argv[1]
    SITE_URL = sys.argv[2]
    SITE_URL = SITE_URL.replace("'", "")
    location=location.replace("'", "")
    if('http' not in SITE_URL):
        SITE_URL = 'http://'+SITE_URL

    p = Pool(4)
    p.apply_async(ck.sitecheck, (location, SITE_URL,))
    p.apply_async(ck.sitecheck2, (location, SITE_URL,))
    source = p.apply_async(at.source, (SITE_URL,))
    tags_colors = p.apply_async(at.colors_tags, (SITE_URL, ))

    p.close()
    p.join()

    basedir = os.path.dirname(location)
    file_path = os.path.join(basedir, 'res.php')
    file_path2 = os.path.join(basedir, 'tm.php')
    to = os.path.join(basedir, 'summary.php')

    # copy css validation
    tobefound = '<strong>Note: Results are provided by http://jigsaw.w3.org/css-validator </strong></li></ol>\n<p class="msg_err">CSS validator error. Unable to generate results from the validator.</p><br>	</div>'
    correct = '</li></ol>\n<br><span class="congrats_msg"><img src="https://achecker.ca/images/feedback.gif" alt="Feedback">  Congratulations! Passed CSS Validation.</span>	</div>'
    new_an_found = '\n <strong>Note: Results are provided by http://jigsaw.w3.org/css-validator </strong>\nreplacehere \n </li></ol></div>'
    new_an_corr = '\nreplacehere \n </li></ol></div>'

    s = open(file_path, encoding='utf-8').read()
    if correct in s:
        s = s.replace(correct, new_an_corr)
        os.remove(file_path2)
    else:
        if tobefound in s:
            s = s.replace(tobefound, new_an_found)
            f = open(file_path, 'w', encoding='utf-8')
            f.write(s)
            f.close()

            lookup = 'replacehere'
            value = '<div class="error-section">'
            with open(file_path2, encoding='utf-8') as f:
                ins_val = f.read()
            ax.find_and_put(file_path, lookup, value, ins_val)
            s = open(file_path, encoding='utf-8').read()
            s = s.replace('replacehere', '')
            f = open(file_path, 'w', encoding='utf-8')
            f.write(s)
            f.close()
            os.remove(file_path2)

    # check autism spec
    lookup1 = '(<span id="AC_num_of_css_errors">'
    value1 = '<li class="navigation"><a href="javascript:void(0);" accesskey="6"'
    iv1 = '\n\t\t\t<li class="navigation"><a href="javascript:void(0);" accesskey="7" title="Autism Summary Alt+7" id="Summary_menu_errors" onclick="AChecker.output.onClickTab(\'Summary_result\');"><span class="nav">Autism Summary</span></a></li>\n'
    ins_val1 = '\n\t\t\t<li class="navigation"><a href="javascript:void(0);" accesskey="6" title="Autism Validation Alt+6" id="Autism_menu_errors" onclick="AChecker.output.onClickTab(\'Autism_result\');"><span class="nav">Autism Validation (<span id="Autism_num_of_errors"></span>)</span></a></li>\n'+iv1
    ax.find_and_put(file_path, lookup1, value1, ins_val1)

    lookup2 = '</fieldset>'
    value2 = '<div id="Autism_result"'
    iv2 = '<div id="Summary_result" class="sum_autism" style="margin-top:1em; display:none;">\n<p hidden>add_summary_here</p>\n</div>\n'
    ins_val2 = '<div id="Autism_result" class="autism" style="margin-top:1em; display:none;">\n<p hidden>addhere</p>\n</div>\n'+iv2
    ax.find_and_put(file_path, lookup2, value2, ins_val2)

    ######################### GIFS ########################
    list_sources_given = source.get()
    srcs = list_sources_given[0]
    text_source = list_sources_given[1]


    gifs = at.search_gif(SITE_URL, srcs)
    if (len(gifs) != 0):
        at.insert_gif_an(file_path, gifs)
    ##################### TEXT IN IMAGES ###############
    lang = ax.find_language(SITE_URL, srcs)
    list_images_in_site, line_nums_img = at.all_images(SITE_URL, srcs)

    if (lang == 'it' or lang == 'en'):
        texts = at.txt_in_pic(file_path, list_images_in_site, line_nums_img)
        mean, num_el, grades, row= at.mean_grades_img(texts, lang)
    #################### TEXT ANALYSIS ##################
        val_cmplx_ = at.cmplx_value(file_path, SITE_URL, mean, num_el, text_source, lang)
        val_cmplx = at.insert_txt_comp(file_path, SITE_URL, mean, num_el, text_source, lang)
        at.insert_text_analysis(file_path, SITE_URL, row, text_source, lang)
    else:
        at.impossible_text_analysis(file_path, lang)
        val_cmplx_ = 'can\'t compute'
    ################### COLORS #################
    col_tag = tags_colors.get()
    l =at.insert_colors_analysis(file_path, SITE_URL, list_images_in_site, col_tag)
    ################### DIV SUMMARY #################
    basedir = os.path.abspath(os.path.join(os.getcwd(), os.pardir))
    file_path_sum = os.path.join(basedir, 'summary.php')

    open(file_path_sum, "w").close()
    at.sumpage(file_path_sum)

    at.summary(file_path_sum, file_path, val_cmplx_, l)
    ax.copyrows(to, file_path)
    