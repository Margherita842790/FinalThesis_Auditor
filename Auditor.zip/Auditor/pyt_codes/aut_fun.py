from urllib.request import urlopen
import pytesseract
import io
from PIL import Image
import re
import os
import spacy
from spacy_readability import Readability
import string
import urllib.request
from bs4 import BeautifulSoup
from selenium import webdriver
import linecache
import fileinput
import sys
import numpy as np
import cv2
import imghdr
from io import BytesIO
import autism.aux_fun as ax

############# source page ##############
def source(url):
    options = webdriver.ChromeOptions()
    options.headless = False
    driver = webdriver.Chrome(options=options)
    driver.get(url)
    html = driver.page_source
    soup = BeautifulSoup(html, features="lxml")
    sp = str(soup.prettify())
    text = driver.find_element_by_tag_name("body").text
    driver.quit()
    list_sources = []
    list_sources.append(sp)
    list_sources.append(text)
    return list_sources;

############## GIF SEARCH #########
def check(url):
    try:
        u = urllib.request.urlopen(url)
        u.close()
        return True
    except:
        return False

def get_content_type(url):
    req = urllib.request.Request(url, headers={'User-Agent': "Magic Browser"})
    data = urllib.request.urlopen(req).read()
    image_type = imghdr.what(None, data)
    if not image_type:
        try:
            image_type = Image.open(BytesIO(data))
        except:
            pass
    return image_type

def find_the_images(sp):
    path = 'temp.txt'
    with open(path, "w", encoding='utf-8') as tmp:
        tmp.write(sp)
    tmp.close()

    with fileinput.FileInput(path, mode='rb', inplace=True) as file:
        for line in file:
            line = line.decode('utf-8')
            line = line.replace(">", ">\n")
            sys.stdout.buffer.write(line.encode('utf-8'))

    line_numb = ax.find_line(path, r'<img')
    aux_string = []
    list_img = []
    list_numbers = []

    for i in line_numb:
        aux_string.append(str(i) + ': ' + linecache.getline(path, i))
    for (i, j) in zip(line_numb, aux_string):
        if "src" in j:
            j = (re.findall(r'src=".*?"', j)[0]).replace('"', "")
            j = j.replace('src=', "")
            if "http" not in j:
                if "//" in j:
                    j = 'http:' + j
                    list_img.append(j)
                else:
                    list_img.append(j)
            else:
                list_img.append(j)
            list_numbers.append(i)
    os.remove(path)
    return list_img, list_numbers

def search_gif(url, srcs):
    list_im, line_numb = find_the_images(srcs)
    list_img = []
    for (i, j) in zip(line_numb, list_im):
        if check(j) == True:
            content = str(get_content_type(j))
            if('webp' in content or 'gif' in content):
                list_img.append(
                    '<tr class="error">\n\t<td>\n\t\t' + '<span class="err_type"><img src="images/error.png" width="15" height="15" alt="Error" title="Error"></span> <em> Line ' + str(
                        i) + ': </em>' + '<pre><code class="input">&lt;img src=' + j + '</code></pre>\n' + '<img src="' + j + '" height="50" border="1"/>\n\t\t</td>\n\t</tr>')
    return list_img

def gifs_to_insert(gifs):
    total = []
    for i in gifs:
        ins_val = '\n' + i + '\n'
        total.append(ins_val)
    strgif = ''.join(total)
    return strgif

def insert_gif_an(file_path, gifs):
    line_number_title = ax.find_line(file_path, '<p hidden>addhere</p>')[0]
    line_number_title = line_number_title - 1
    start_title = '<br>\n\t<h3 style="padding-left:10px">Presence of auto-animated images</h3>\n\t<div class="gd_one_check">\n\t<table id="tb_problems_aut" class="data static">\n\t<tbody>\n'
    end_title = '\t\t<p hidden>addheregif</p>\n</tbody>\n\t</table>\n</div>\n'
    value_title = start_title
    ins_val_title = start_title + end_title
    ax.put(file_path, line_number_title, value_title, ins_val_title)

    strg = gifs_to_insert(gifs)
    line_number = ax.find_line(file_path, 'addheregif')[0]
    line_number = line_number - 1
    ax.put(file_path, line_number, strg, strg)

    return


########## TEXT IN IMAGE ################

def all_images(url, soup):
    hs = urllib.parse.urlparse(url)
    host = '{uri.scheme}://{uri.netloc}/'.format(uri=hs)
    images = []
    line_nums = []
    list_im, line_numb = find_the_images(soup)
    for (x, y) in zip(list_im, line_numb):
        if 'data:image' not in x:
            boolean_parse = bool(urllib.parse.urlparse(x).netloc)
            if boolean_parse == False:
                x=host + x
            t = str(get_content_type(x))
            if 'webp' not in t and 'gif' not in t:
                images.append(x)
        else:
            images.append(x)
    images = list(dict.fromkeys(images))
    path = 'temp.txt'
    with open(path, "w", encoding='utf-8') as tmp:
        tmp.write(soup)
    tmp.close()
    for i in images:
        line_nums.append(ax.find_line(path,i))
    os.remove(path)
    return images, line_nums

def text_in_img(url):
    headers = {'User-Agent': 'Mozilla 5.10'}
    request = urllib.request.Request(url, None, headers)
    response = urllib.request.urlopen(request)
    imagetext = ''
    try:
        if ax.is_grey_scale(io.BytesIO(response.read()))==False :
            arr = np.asarray(bytearray(response.read()), dtype=np.uint8)
            if arr.size != 0:
                img = cv2.imdecode(arr, -1)  # 'Load it as it is'
                if img is not None:
                    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                    basedir = os.getcwd()
                    dirtess = os.path.join(basedir, 'tesseract.exe')
                    pytesseract.pytesseract.tesseract_cmd = dirtess
                    imagetext = pytesseract.image_to_string(gray, config='--tessdata-dir dirtess')
    except:
        pass
    return imagetext, url

def txt_in_pic(file_path, urls, line_numbers):
    list_pics = []
    list_texts = []
    lung_urls = len(urls)
    if lung_urls != 0:
        for (x, y) in zip(urls, line_numbers):
            if 'data:' not in x:
                testo, u = text_in_img(x)
            else:
                testo=''
            if testo != '':
                line_wrn = str(y).strip('[]')
                val = '<tr class="error">\n\t<td>\n\t\t' + '<span class="err_type"><img id="msg_icon_24_3_94" src="images/warning.png" alt="Warning: Confirmation Required" title="Warning: Confirmation Required" width="15" height="15"></span><em> Line ' + line_wrn + ': </em>' + '<pre><code class="input">&lt;img src=' + u + '</code></pre>\n' + '<img src="' + u + '" height="50" border="1"/>\n\t\t</td>\n\t</tr>'
                list_pics.append(val)
                list_texts.append(testo)
        valinput = '\n'.join(list_pics)
        if valinput != '':
            presence_text_img(file_path, valinput)
    return list_texts

def presence_text_img(file_path, text):
    start = '<br>\n\t<h3 style="padding-left:10px">Presence of text in images</h3>\n\t<div class="gd_one_check">\n\t<table id="tb_problems_aut" class="data static">\n\t<tbody>\n'
    end = '\t\t</tbody>\n\t</table>\n</div>\n'
    value = start
    ins_val = start + text + end
    line_number = ax.find_line(file_path, '<p hidden>addhere</p>')[0]
    line_number = line_number - 1
    ax.put(file_path, line_number, value, ins_val)
    return

def mean_grades_img(texts, lang):
    list_img_complex_rows = []
    list_img_complex_grades = []
    for t in texts:
        t = t.strip(string.punctuation)
        row, grade = text_complexity_image(t, lang)
        list_img_complex_rows.append(row)
        list_img_complex_grades.append(grade)

    flattened = [val for sublist in list_img_complex_grades for val in sublist]
    flattened_row = [val for sublist in list_img_complex_rows for val in sublist]
    media = 0
    if len(flattened) != 0:
        for i in flattened:
            media = media + i
        media = media / len(flattened)
    else:
        media=0
    return media, len(flattened), flattened, flattened_row

############ TEXT READABILITY #############

def gulpease(doc):
    translator = str.maketrans('', '', string.punctuation)
    count = lambda l1, l2: sum([1 for x in l1 if x in l2])
    punti = count(doc, set(string.punctuation))
    sentence = doc.translate(translator)
    s = sentence.replace(" ", "")
    lettere = len(s)
    parole = len(sentence.split())
    if parole != 0:
        indiceG = 89 + ((300 * punti) - (10 * lettere)) / parole
    else:
        indiceG = 0
    if indiceG > 100:
        indiceG = 100
    return indiceG

def text_site(t):
    t = re.sub(r"[^\w^\s^.;,:\'\"?!%$£()]", "", t)
    t = re.sub(r"\s\s+", "\n", t)
    t = t.strip().replace('\n', '. ')
    return t

def text_complexity_site(site, soup, lang):
    t = text_site(soup)
    result, grade = text_complexity(t, lang)
    return result, grade

def text_complexity_image(t, lang):
    t = re.sub(r"[^\w^\s^.;,:\'\"?!%$£()]", "", t)
    t = re.sub(r"\s\s+", "\n", t)
    t = t.strip().replace('\n', '. ')
    return text_complexity(t, lang)

def text_complexity(t, lang):
    grade = []
    result = []
    if lang == 'it':
        nlp = spacy.load("it_core_news_sm")
        doc = nlp(t)
        sent_list = []
        for sent in doc.sents:
            sent_list.append(sent.text)
        read = Readability()
        nlp.add_pipe(read, last=True)
        for x in sent_list:
            grade.append(gulpease(x))
        for (i, j) in zip(sent_list, grade):
            if 0 <= j <= 50:
                start = '<span style="background-color: #ff5454">'
                end = '</span>'
                value = start + i + end
                result.append(value)
            if 51 <= j <= 70:
                start = '<span style="background-color: #ff9642">'
                end = '</span>'
                value = start + i + end
                result.append(value)
            if 71 <= j <= 80:
                start = '<span style="background-color: #ffff00">'
                end = '</span>'
                value = start + i + end
                result.append(value)
    else:
        if lang == 'en':
            nlp = spacy.load("en_core_web_sm")
            doc = nlp(t)
            sent_list = []
            for sent in doc.sents:
                sent_list.append(sent.text)
            read = Readability()
            nlp.add_pipe(read, last=True)
            for x in sent_list:
                docs = nlp(x)
                # grade.append(docs._.automated_readability_index)
                grade.append(docs._.flesch_kincaid_reading_ease)
            for (i, j) in zip(sent_list, grade):
                if 0 <= j <= 40:
                    start = '<span style="background-color: #ff5454">'
                    end = '</span>'
                    value = start + i + end
                    result.append(value)
                if 41 <= j <= 60:
                    start = '<span style="background-color: #ff9642">'
                    end = '</span>'
                    value = start + i + end
                    result.append(value)
                if 61 <= j <= 80:
                    start = '<span style="background-color: #ffff00">'
                    end = '</span>'
                    value = start + i + end
                    result.append(value)
        else:
            value = "text complexity can't be analysed: different from en and it"
            result.append(value)
    return result, grade

def total_complexity(site, mean, num_el, soup, lang):
    result, grade = text_complexity_site(site, soup, lang)
    numtot = len(grade)
    somma = 0
    for x in grade:
        somma = somma + x
    media = somma / numtot
    media = round(media, 2)
    if mean != 0:
        media = (numtot*(media)+num_el*(mean))/(numtot+num_el)
    return media

def cmplx_value(file_path, site, mean, num_el, soup, lang):
    text_cmplx = total_complexity(site, mean, num_el, soup, lang)
    return text_cmplx;

def insert_txt_comp(file_path, site, mean, num_el, soup, lang):
    text_cmplx = total_complexity(site, mean, num_el, soup, lang)
    result, grades = text_complexity_site(site, soup, lang)
    start = '<br>\n\t<h3 style="padding-left:10px">Text readability</h3>\n\t<div class="gd_one_check">\n\t<table id="tb_problems_aut" class="data static">\n\t<tbody>\n'
    end = '\t\t</tbody>\n\t</table>\n</div>\n'

    value = start
    val_rd = '%.2f' % text_cmplx
    style = '<style>\n.w3-container:after,.w3-container:before {\n\tcontent:"";\n\tdisplay:table;\n\tclear:both;\n\tpadding:0.01em 16px;width: 50%;\n}\n.w3-light-grey {\n\tcolor:#000!important;\n\tbackground-color:#f1f1f1!important;width: 50%;\n\t}\n.progress {\n\tcolor:#fff!important;\n\tbackground-color:#3aafab!important;\n\tdisplay:inline-block;\n\twidth:auto;\n\ttext-align:center!important;\n}\n</style>\n'
    divs = '<br><div class="w3-container" style="padding-left:10px">\n\t<div class="w3-light-grey">\n\t\t<div class="progress" style="width:' + str(
        text_cmplx) + '%">' + str(val_rd) + '%</div>\n\t</div>\n</div>'
    ins_val = style + start + divs + end

    line_number = ax.find_line(file_path, '<p hidden>addhere</p>')[0]
    line_number = line_number - 1
    ax.put(file_path, line_number, value, ins_val)

    lun_result=len(result)
    if lun_result > 0:
        start1 = '<br>\n\t<h2 style="padding-left:10px">Text readability - details</h2>\n\t\t<div class=“row_colors” style="padding-left:10px;">\n\t\t<div class=“square” style="display: inline-block;background-color: #ffff00;">sentences fairly difficult to read</div>\n\t\t<div class=“square” style="display: inline-block;background-color: #ff9642;">sentences difficult to read</div>\n\t\t<div class=“square” style="display: inline-block;background-color: #ff5454;">sentences very difficult to read</div>\n\t\t</div><br>\n<div class="gd_one_check">\n\t<table id="tb_problems_aut" class="data static">\n\t\n'
        end1 = '\n<p hidden>txtcmpl</p>\n\t\t\n\t</table>\n</div>\n'

        value1 = start1
        line_number1 = ax.find_line(file_path, '<p hidden>addhere</p>')[0]
        line_number1 = line_number1 - 1
        ins_val1 = start1 + end1
        ax.put(file_path, line_number1, value1, ins_val1)
    return val_rd


def insert_text_analysis(file_path, site, row, soup, lang):
    result, grades = text_complexity_site(site, soup, lang)
    res = list(set(result+row))
    count = len(res);
    if count != 0:
        line_number = ax.find_line(file_path, '<p hidden>txtcmpl</p>')[0]
        line_number = line_number - 1
        for x in res:
            start = '<tr>\n\t<td style="white-space: nowrap;">\n\t\t<span class="err_type"><img id="msg_icon_24_3_94" src="images/warning.png" alt="Warning: Confirmation Required" title="Warning: Confirmation Required" width="15" height="15"></span> <em> Issue ' + str(count) + ': </em></td><td>'
            end = '\n\t\t</td>\n\t</tr>'
            value = start
            ins_val = start + x + end
            ax.put(file_path, line_number, value, ins_val)
            count = count - 1
    return

def impossible_text_analysis(file_path, lang):
    start = '<br>\n\t<h3 style="padding-left:10px">Can\'t compute Text readability</h3>\n\t<div class="gd_one_check">\n\t<p style="padding-left:10px">The webpage\'s language is different from english or italian</p><table id="tb_problems_aut" class="data static">\n\t<tbody>\n'
    end = '\t\t</tbody>\n\t</table>\n</div>\n'
    value = start
    ins_val = start + end
    line_number = ax.find_line(file_path, '<p hidden>addhere</p>')[0]
    line_number = line_number - 1
    ax.put(file_path, line_number, value, ins_val)
    return

########### COLORS ANALYSIS ##########
def colors_tags(url):
    options = webdriver.ChromeOptions()
    options.headless = False
    driver = webdriver.Chrome(options=options)
    driver.get(url)
    lista_caso = []
    html_source = driver.page_source
    faces_txt = re.findall(r'<[a-zA-Z]+', html_source)
    not_these = ['<html', '<head', '<meta', '<title', '<link', '<script', '<style', '<noscript', '<img', '<i', '<sup']
    for x in faces_txt:
        if (x not in not_these):
            lista_caso.append(x.replace('<', ''))
    lista_caso = list(dict.fromkeys(lista_caso))
    lista_finale_tuple = []
    for i in lista_caso:
        tag = driver.find_elements_by_tag_name(i)
        tag_back_col = []
        tag_col = []
        tag_img = []
        tag_border = []
        tag_back_col_1 = []
        tag_col_1 = []
        tag_img_1 = []
        tag_border_1 = []
        for j in tag:
            try:
                back_col = j.value_of_css_property('background-color')
                back_col = ax.clean_colors(back_col)
                tag_back_col.append(back_col)
                col = j.value_of_css_property('color')
                col = ax.clean_colors(col)
                tag_col.append(col)
                bord = j.value_of_css_property('border-color')
                bord = ax.clean_colors(bord)
                tag_border.append(bord)
                img = j.value_of_css_property('background-image')
                img = ax.clean_img(img)
                tag_img.append(img)
            except:
                pass
        for k in tag_back_col:
            color1 = ax.rgb2hex(k)
            tupla1 = (ax.rgb2hsv(k))
            if ax.thresholds(tupla1[0], tupla1[1]) == False:
                if ax.black_grey_white(k, tupla1) == False:
                    tag_back_col_1.append(' ' + color1)

        for k in tag_col:
            color2 = ax.rgb2hex(k)
            tupla2 = (ax.rgb2hsv(k))
            if ax.thresholds(tupla2[0], tupla2[1]) == False:
                if ax.black_grey_white(k, tupla2) == False:
                    tag_col_1.append(' ' + color2)

        for k in tag_border:
            color3 = ax.rgb2hex(k)
            tupla3 = (ax.rgb2hsv(k))
            if ax.thresholds(tupla3[0], tupla3[1]) == False:
                if ax.black_grey_white(k, tupla3) == False:
                    tag_border_1.append(' ' + color3)

        for k in tag_img:
            if k != 'none':
                if ax.is_image(k) == True:
                    cont_type = get_content_type(k)
                    if ('webp' not in cont_type) and ('gif' not in cont_type):
                        rgb = ax.image_proc(k)
                        lung_rgb = len(rgb)
                        if lung_rgb > 2:
                            color4 = ax.rgb2hex(rgb)
                            tupla4 = (ax.rgb2hsv(rgb))
                            if ax.thresholds(tupla4[0], tupla4[1]) == False:
                                if ax.black_grey_white(rgb, tupla4) == False:
                                    tag_img_1.append(' ' + color4)

        i = i + ': ' + ''.join(tag_back_col_1) + ''.join(tag_col_1) + ''.join(tag_border_1) + ''.join(tag_img_1)
        i = ' '.join(ax.unique_list(i.split()))
        lista_finale_tuple.append(i)

    driver.quit()
    return lista_finale_tuple

def colors_list(images_list, lista_finale_tuple):
    tag_imgs_in_site = []
    for h in images_list:
        rgb = ax.image_proc(h)
        lun_rgb = len(rgb)
        if lun_rgb > 2:
            color5 = ax.rgb2hex(rgb)
            tupla5 = (ax.rgb2hsv(rgb))
            if ax.thresholds(tupla5[0], tupla5[1]) == False:
                if ax.black_grey_white(rgb, tupla5) == False:
                    tag_imgs_in_site.append(h + ' ' + color5 + ' ')
    nuova = ''.join(tag_imgs_in_site)
    lista_finale_tuple.append(nuova)
    newlist = []
    for lft in lista_finale_tuple:
        if '#' in lft:
            newlist.append(lft)
    return newlist

def insert_colors_analysis(file_path, site, images_list, lista_finale_tuple):
    list_colors = colors_list(images_list, lista_finale_tuple)
    list_f = []
    dim_list_colors = len(list_colors)
    if dim_list_colors != 0:
        start = '<br>\n\t<h3 style="padding-left:10px">Colors difficulties</h3>\n\t<div class="gd_one_check">\n\t<table id="tb_problems_aut" class="data static">\n\t<tbody>\n<tr class="error">\n\t\t\t<td>\n\t\t\t\t<span class="err_type"><img id="msg_icon_24_3_94" src="images/warning.png" alt="Warning: Confirmation Required" title="Warning: Confirmation Required" width="15" height="15"></span> Issues: </td><td>'
        end = '\t\t\t</td>\n</tr>\t\t</tbody>\n\t</table>\n</div>\n'

        value = start
        for i in list_colors:
            left_text = i.partition("#")[0]
            fc = re.findall(r'#[a-zA-Z0-9]+', i)[0]
            newline = '<span style="margin-right:10px">' + left_text + fc + '</span>'
            colors = '<div class="circle" style="background:' + fc + ';"></div>'
            final = newline + colors
            list_f.append(final)
        list_f = ' '.join(list_f)
        ins_val = start + list_f + end

        line_number = ax.find_line(file_path, '<p hidden>addhere</p>')[0]
        line_number = line_number - 1
        ax.put(file_path, line_number, value, ins_val)
    return list_f

############### SUMMARY ##############
def checkex(file, string):
    bol = False
    if string in open(file, encoding="utf8").read():
        bol = True
    return bol

def yesorno(t, file_to, line_num, name, complexity, list_colors):
    if t == True:
        if name == 'TxtC':
            value = '<td> <img src="images/error.png" alt="' + name + '" height="12" width="12"></td>'
            ins_val = '\t\t<td> <img src="images/error.png" alt="' + name + '" height="12" width="12"></td>\n\t\t<td>Readability reached: ' + str(
                complexity) + '% </td>\n'
            ax.put(file_to, line_num, value, ins_val)
        else:
            if name == 'coldiff':
                value = '<td> <img src="images/error.png" alt="' + name + '" height="12" width="12"></td>'
                ins_val = '\t\t<td> <img src="images/error.png" alt="' + name + '" height="12" width="12"></td>\n\t\t<td>Colors: ' + list_colors + '</td>\n'
                ax.put(file_to, line_num, value, ins_val)
            else:
                value = '<td> <img src="images/error.png" alt="' + name + '" height="12" width="12"></td>'
                ins_val = '\t\t<td> <img src="images/error.png" alt="' + name + '" height="12" width="12"></td>\n'
                ax.put(file_to, line_num, value, ins_val)
    else:
        if name == 'TxtC':
            value = '<td> <img src="images/nan.png" alt="' + name + '" height="12" width="12"></td>'
            ins_val = '\t\t<td> <img src="images/nan.png" alt="' + name + '" height="12" width="12"></td>\n\t\t<td>Readability reached: ' + str(complexity) + ' </td>\n'
            ax.put(file_to, line_num, value, ins_val)
        else:
            value = '<td> <img src="images/green_tick.png" alt="' + name + '" height="12" width="12"></td>'
            ins_val = '\t\t<td> <img src="images/green_tick.png" alt="' + name + '" height="12" width="12"></td>\n'
            ax.put(file_to, line_num, value, ins_val)
    return

def summary(file_to, file_from, complexity, list_colors):
    # Text Difficulties 1
    t1 = checkex(file_from, 'Text readability - details')
    lookup1 = 'Text Difficulties'
    line_num1 = ax.find_line(file_to, lookup1)[0]
    name1 = 'TxtD'
    yesorno(t1, file_to, line_num1, name1, complexity, list_colors)
    # Overall Text readability
    t2 = checkex(file_from, 'Text readability')
    lookup2 = 'Overall Text readability'
    line_num2 = ax.find_line(file_to, lookup2)[0]
    name2 = 'TxtC'
    yesorno(t2, file_to, line_num2, name2, complexity, list_colors)
    # Presence of text in images
    t3 = checkex(file_from, 'Presence of text in images')
    lookup3 = 'Presence of text in images'
    line_num3 = ax.find_line(file_to, lookup3)[0]
    name3 = 'Tinimg'
    yesorno(t3, file_to, line_num3, name3, complexity, list_colors)
    # Presence of animated images
    t4 = checkex(file_from, 'Presence of animated images')
    lookup4 = 'Presence of animated images'
    line_num4 = ax.find_line(file_to, lookup4)[0]
    name4 = 'gifs'
    yesorno(t4, file_to, line_num4, name4, complexity, list_colors)
    # Colors difficulties
    t5 = checkex(file_from, 'Colors difficulties')
    lookup5 = 'Colors difficulties'
    line_num5 = ax.find_line(file_to, lookup5)[0]
    name5 = 'coldiff'
    yesorno(t5, file_to, line_num5, name5, complexity, list_colors)
    return

def sumpage(file_path_to):
    basedir = os.path.abspath(os.path.join(os.getcwd(), os.pardir))
    file_path_from = os.path.join(basedir, 'from.php')
    list_beg = list(range(74, 314))
    newfile = open(file_path_to, "w", encoding="utf8")
    with open(file_path_from, "r") as file:
        for i, line in enumerate(file):
            if i in list_beg:
                newfile.write(line)
        newfile.write("\n")
    newfile.close()
    return