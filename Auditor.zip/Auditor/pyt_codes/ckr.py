import urllib
from selenium import webdriver
from selenium.webdriver.support.ui import Select
from bs4 import BeautifulSoup
import os
from pathlib import Path

def sitecheck(location, SITE_URL):
    URL = "https://achecker.ca/checker/index.php"

    payload = {
        'uri': SITE_URL,
        'enable_html_validation': 'on',
        'enable_css_validation': 'on',
        'show_source': 'on',
        'radio_gid[]': '3'
    }
    payload = urllib.parse.urlencode(payload).encode("utf-8")
    # prepare the option for the chrome driver and start chrome driver
    options = webdriver.ChromeOptions()
    options.headless = False
    driver = webdriver.Chrome(options=options)
    driver.get(URL)
    inputElement = driver.find_element_by_id("checkuri")
    inputElement.send_keys(SITE_URL)
    driver.find_element_by_link_text("Options").click()        driver.find_element_by_id("enable_html_validation").click()
    driver.find_element_by_id("enable_css_validation").click()
    driver.find_element_by_id("radio_gid_3").click()
    driver.find_element_by_name("validate_uri").click()
    element =  driver.find_element_by_id("output_div");
    html1 =driver.execute_script("return arguments[0].innerHTML;", element)
    driver.quit()

    basedir=os.path.abspath(os.path.join(os.getcwd(), os.pardir))

    file_path_to = os.path.join(basedir, 'res.php')
    file_path_from = os.path.join(basedir, 'from.php')
    list_beg = list(range(1, 51))
    list_end = list(range(54, 74))
    newfile = open(file_path_to, "w", encoding="utf8")
    with open(file_path_from, "r") as file:
        for i, line in enumerate(file):
            if i in list_beg:
                newfile.write(line)
        newfile.write(html1)
        newfile.write("\n")
    newfile = open(file_path_to, "a", encoding="utf8")
    with open(file_path_from, "r") as file:
        for j, line in enumerate(file):
            if j in list_end:
                newfile.write(line)
    newfile.close()
    return ;

def sitecheck2(location, SITE_URL):
    URL = "https://jigsaw.w3.org/css-validator/"
    options = webdriver.ChromeOptions()
    options.headless = False
    options.add_argument("--lang=en")
    driver = webdriver.Chrome(options=options)
    driver.get(URL)
    inputElement = driver.find_element_by_id("uri")
    inputElement.send_keys(SITE_URL)
    driver.find_element_by_link_text("More Options").click()
    select1 = Select(driver.find_element_by_id('profile_uri'))
    select1.select_by_value('none')
    select2 = Select(driver.find_element_by_id('medium_uri'))
    select2.select_by_value('all')
    select3 = Select(driver.find_element_by_id('warning_uri'))
    select3.select_by_value('2')
    select4 = Select(driver.find_element_by_id('vext_warning_uri'))
    select4.select_by_visible_text('Default')
    driver.find_elements_by_class_name("submit")[0].click()
    element = driver.find_element_by_id("errors");
    html = driver.execute_script("return arguments[0].innerHTML;", element)
    driver.quit()
    soup = BeautifulSoup(html, features="lxml")
    mydivs = soup.findAll("div", {"class": "error-section-all"})[0]
    html_content = mydivs.prettify()
    basedir = os.path.abspath(os.path.join(os.getcwd(), os.pardir))
    file_path_to = os.path.join(basedir, 'tm.php')
    with open(file_path_to, "w") as file:
        file.write(html_content)
    return ;
