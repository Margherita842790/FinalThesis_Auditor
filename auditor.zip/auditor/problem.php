<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<title>Not found</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="autism ,free, open source, accessibility checker, accessibility reviewer, accessibility evaluator, accessibility evaluation, evaluate accessibility, test accessibility, review accessibility, STANCA." />
	<meta name="description" content="Web accessibility evalution tool to help developer and parents ensure Web content is accessible to people with autism." />
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/ac_out_style.css">
        <link rel="stylesheet" href="css/navbar.css">
        <script src="js/jquery.js" type="text/javascript"></script>
        <script src="js/checker.js" type="text/javascript"></script>
        <script src="js/done_js.js" type="text/javascript"></script>


<style>
.fixed {
  position: fixed;
  top:0; left:0;
  width: 100%;
}
</style>

</head>
<body class="Site" onload="srcFunction()">
    <header>
      <div class="home">
          <div id="colh_1" class="colh_1">

            <div class="home_1">
              <a href="index.php">
                <img src="images/logo_white2.png">
            </a>
          </div>
          <div class="home_sub_logo" id="home_sub_logo">webpage validator for autism</div>

          </div>


            <div id="colh_2" class="colh_2">
              <a href="help.php" target="_blank"> <img src="images/question-mar.png">  </a>
            </div>

      </div>

  </header>

<section class="Site-content" style="background-color: #fff;" >
<style>

#ok {
text-align: center;
position: absolute;
  margin: auto;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  width: 50%;
  height: 50%;
}

.classok {
  padding: 20px;
}

</style>

<div id="ok">

<h1> Ops! </h1>
<p> Provided url doesn't exist on the web!</p>

</div>


<br><br>



</div>


</section>
<footer>
          <div class="footer">
              <div class="footer_1">
                  CREATED BY: Margherita Rossi
              </div>
          </div>
    </footer>

</body>
</html>

