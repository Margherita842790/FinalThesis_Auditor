<?php
ob_start();
if(file_exists("/var/www/html/auditor/request_result.txt"))
{
unlink("/var/www/html/auditor/request_result.txt");
}

$url = $_POST["site"];
$protocol = "http://";
$p2 = "http";

$isthere=preg_match("/{$p2}/i", $url);
if($isthere === 0){
  $url = $protocol.$url;
}

do{
    sleep(1);
}while(file_exists("/var/www/html/auditor/dl.txt"));
$fdl = fopen("/var/www/html/auditor/dl.txt","w");
chmod("/var/www/html/auditor/dl.txt", 0777);


if(file_exists("/var/www/html/auditor/thumb.png")){
 unlink("/var/www/html/auditor/thumb.png");
}

$path="pyt";
$dir = chdir($path); 
list($scriptPath) = get_included_files();
//echo var_dump($_POST['usprog']);
$headers = @get_headers($url);
//echo $headers[0];
if($headers[0] == 'HTTP/1.1 301 Moved Permanently'|| $headers[0]=='HTTP/1.1 403 Forbidden' || $headers[0] == 'HTTP/1.1 404 Not Found'){
	echo "404";
}

else{
       exec("/var/www/html/auditor/env/bin/python3 -W ignore main.py '$scriptPath' '$url'");

if(file_get_contents("/var/www/html/auditor/request_result.txt")=='0')
{echo "0";}
else{

       if(isset($_POST['usprog'])){
        if($_POST['usprog']=="normal")
        { 
           echo "2";
        }    
        else
        {
           echo "3";
        }
     }
}
}
?>
