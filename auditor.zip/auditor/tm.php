<div class="error-section-all">
 <div class="error-section">
  <h4>
   URI :
   <a href="http://www.arpa.veneto.it/portal_css/arpav_theme/resourcejquery-cachekey7609.css">
    http://www.arpa.veneto.it/portal_css/arpav_theme/resourcejquery-cachekey7609.css
   </a>
  </h4>
  <table>
   <tbody>
    <tr class="error">
     <td class="linenumber" title="Line 461">
      461
     </td>
     <td class="codeContext">
      .ui-datepicker-cover
     </td>
     <td class="parse-error">
      Parse Error
      <span class="unrecognized">
       mask()
      </span>
     </td>
    </tr>
   </tbody>
  </table>
  <!--end of individual error section-->
 </div>
 <div class="error-section">
  <h4>
   URI :
   <a href="http://www.arpa.veneto.it/portal_css/arpav_theme/++resource++tcp_stylesheets/cookiepolicy.css">
    http://www.arpa.veneto.it/portal_css/arpav_theme/++resource++tcp_stylesheets/cookiepolicy.css
   </a>
  </h4>
  <table>
   <tbody>
    <tr class="error">
     <td class="linenumber" title="Line 10">
      10
     </td>
     <td class="codeContext">
      #viewlet-cookiepolicy
     </td>
     <td class="parse-error">
      Value Error :  background-image                                             The first argument to the
      <code>
       linear-gradient
      </code>
      function should be
      <code>
       to top
      </code>
      , not
      <code>
       top
      </code>
      <span class="skippedString">
       )
      </span>
     </td>
    </tr>
   </tbody>
  </table>
  <!--end of individual error section-->
 </div>
 <div class="error-section">
  <h4>
   URI :
   <a href="http://www.arpa.veneto.it/portal_css/arpav_theme/ploneglossary_popup-cachekey5199.css">
    http://www.arpa.veneto.it/portal_css/arpav_theme/ploneglossary_popup-cachekey5199.css
   </a>
  </h4>
  <table>
   <tbody>
    <tr class="error">
     <td class="linenumber" title="Line 345">
      345
     </td>
     <td class="nocontext">
     </td>
     <td class="parse-error">
      Parse Error
      <span class="unrecognized">
       [
----------------------------------*/
/* */
.ui-corner-tl]
      </span>
     </td>
    </tr>
    <tr class="error">
     <td class="linenumber" title="Line 355">
      355
     </td>
     <td class="nocontext">
     </td>
     <td class="parse-error">
      Parse Error
      <span class="unrecognized">
       /* *//
.ui-widget-overlay { background: #5c5c5c url(ui.datepicker/ui-bg_flat_50_5c5c5c_40x100.png) 50% 50% repeat-x; opacity: .80;filter:Alpha(Opacity=80); }
      </span>
     </td>
    </tr>
    <tr class="error">
     <td class="linenumber" title="Line 408">
      408
     </td>
     <td class="codeContext">
      .ui-datepicker-cover
     </td>
     <td class="parse-error">
      Parse Error
      <span class="unrecognized">
       mask()
      </span>
     </td>
    </tr>
    <tr class="error">
     <td class="linenumber" title="Line 415">
      415
     </td>
     <td class="nocontext">
     </td>
     <td class="parse-error">
      Parse Error
      <span class="skippedString">
       }
      </span>
     </td>
    </tr>
   </tbody>
  </table>
 </div>
</div>
