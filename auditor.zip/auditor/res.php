<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<title>Results</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="autism ,free, open source, accessibility checker, accessibility reviewer, accessibility evaluator, accessibility evaluation, evaluate accessibility, test accessibility, review accessibility, STANCA." />
	<meta name="description" content="Web accessibility evalution tool to help developer and parents ensure Web content is accessible to people with autism." />
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/ac_out_style.css">
        <link rel="stylesheet" href="css/navbar.css">
        <script src="js/jquery.js" type="text/javascript"></script>
        <script src="js/checker.js" type="text/javascript"></script>
        <script src="js/done_js.js" type="text/javascript"></script>


<style>
.fixed {
  position: fixed;
  top:0; left:0;
  width: 100%;
}
</style>

</head>
<body class="Site" onload="srcFunction()">
    <header>
      <div class="home">
          <div id="colh_1" class="colh_1">

            <div class="home_1">
              <a href="index.php">
                <img src="images/logo_white2.png">
            </a>
          </div>
          <div class="home_sub_logo" id="home_sub_logo">webpage validator for autism</div>

          </div>


            <div id="colh_2" class="colh_2">
              <a href="help.php" target="_blank"> <img src="images/question-mar.png">  </a>
            </div>

      </div>

  </header>
    
<section class="Site-content" style="background-color: #fff;" >
          



	<div class="center-input-form">
	<a name="report" title="Start Report"></a>
	<fieldset class="group_form"><legend class="group_form">Accessibility Review</legend>
	<h3>Accessibility Review (Guidelines: <a title="Stanca Act(link opens in a new window)" target="_new" href="https://achecker.ca/guideline/view_guideline.php?id=3">Stanca Act</a>)</h3>

	<div class="center">
		<form name="file_form" enctype="multipart/form-data" method="post">

		<fieldset id="report_file"><legend class="report_file">Export Report</legend>
			<div style="padding: 0.5em;">
				<label for="file_type">Export Format:</label>
				<select name="file_menu" id="fileselect">
					<option value="pdf" selected="selected">PDF</option>
					<option value="earl">EARL</option>
					<option value="csv">CSV</option>
					<option value="html">HTML</option>
				</select>&nbsp;&nbsp;&nbsp;&nbsp;
			
				&nbsp;&nbsp;<label for="problem_type">Report to Export:</label>
				<select name="problem_menu" id="problemselect">
					<option value="all" selected="selected">All</option>
					<option value="known">Known</option>
					<option value="likely">Likely</option>
					<option value="potential">Potential</option>
					<option value="html">HTML Validation</option>
					<option value="css">CSS Validation</option>
				</select>&nbsp;&nbsp;&nbsp;&nbsp;

				<iframe id="downloadFrame" src="" style="display:none;"></iframe>
				<input class="report_file_button" type="button" name="validate_export" id="validate_file_button" value="Get File" onclick="return AChecker.input.validateFile('spinner_export');">
				<div class="spinner_div">
					<img class="spinner_img" id="spinner_export" style="display:none" src="https://achecker.ca/themes/default/images/spinner.gif" alt="Accessibility Validation in Progress">
					&nbsp;
				</div>
			</div>
		</fieldset>
	
		</form>
	</div>

	<div class="topnavlistcontainer"><br>
		<ul class="navigation">
			<li class="navigation"><a href="javascript:void(0);" accesskey="1" title="Known Problems Alt+1" id="AC_menu_errors" onclick="AChecker.output.onClickTab('AC_errors');" class="active"><span class="nav">Known Problems(<span id="AC_num_of_errors">3</span>)</span></a></li>

			<li class="navigation"><a href="javascript:void(0);" accesskey="2" title="Likely Problems Alt+2" id="AC_menu_likely_problems" onclick="AChecker.output.onClickTab('AC_likely_problems');"><span class="nav">Likely Problems (<span id="AC_num_of_likely">14</span>)</span></a></li>

			<li class="navigation"><a href="javascript:void(0);" accesskey="3" title="Potential Problems Alt+3" id="AC_menu_potential_problems" onclick="AChecker.output.onClickTab('AC_potential_problems');"><span class="nav">Potential Problems (<span id="AC_num_of_potential">147</span>)</span></a></li>

			<li class="navigation"><a href="javascript:void(0);" accesskey="4" title="HTML Validation Alt+4" id="AC_menu_html_validation_result" onclick="AChecker.output.onClickTab('AC_html_validation_result');"><span class="nav">HTML Validation (<span id="AC_num_of_html_errors">5</span>)</span></a></li>

			<li class="navigation"><a href="javascript:void(0);" accesskey="5" title="CSS Validation Alt+5" id="AC_menu_css_validation_result" onclick="AChecker.output.onClickTab('AC_css_validation_result');"><span class="nav">CSS Validation (<span id="AC_num_of_css_errors">6</span>)</span></a></li>

			<li class="navigation"><a href="javascript:void(0);" accesskey="6" title="Autism Validation Alt+6" id="Autism_menu_errors" onclick="AChecker.output.onClickTab('Autism_result');"><span class="nav">Autism Validation (<span id="Autism_num_of_errors"></span>)</span></a></li>

			<li class="navigation"><a href="javascript:void(0);" accesskey="7" title="Autism Summary Alt+7" id="Summary_menu_errors" onclick="AChecker.output.onClickTab('Summary_result');"><span class="nav">Autism Summary</span></a></li>
		</ul>
	</div>

	<div id="AC_errors">
	<br>
	<span id="AC_congrats_msg_for_errors">
	</span>
<h3>Requirement 1: Conform To Specifications</h3><br>
        <div class="gd_one_check"> 
           <span class="gd_msg">Check 232: 
              <a href="https://achecker.ca/checker/suggestion.php?id=232" onclick="AChecker.popup('https://achecker.ca/checker/suggestion.php?id=232'); return false;" target="_new">Document does not validate.</a>
           </span>

           <div class="gd_question_section">
                    <span style="font-weight:bold">Repair: </span>Validate the document using a validator service.

           
           </div>
         
           <table id="tb_problems_" class="data static">
                      <tbody><tr>
             <td>         <span class="err_type"><img id="msg_icon_9_1_232" src="https://achecker.ca/images/error.png" alt="Error" title="Error" width="15" height="15"></span>
         <em>Line 9, Column 1</em>:
         <pre><code class="input">&lt;html xmlns="http://www.w3.org/1999/xhtml" xml:lang="it"
      lang="it"&gt;

  
    
    
    
    
   ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>

           
           </tbody></table>
         </div>
<h3>Requirement 15: Script/Object Alternatives</h3><br>
        <div class="gd_one_check"> 
           <span class="gd_msg">Check 90: 
              <a href="https://achecker.ca/checker/suggestion.php?id=90" onclick="AChecker.popup('https://achecker.ca/checker/suggestion.php?id=90'); return false;" target="_new"><code>script</code> must have a <code>noscript</code> section.</a>
           </span>

           <div class="gd_question_section">
                    <span style="font-weight:bold">Repair: </span>Add a <code>noscript</code> section immediately following the <code>script</code> that provides the same functionality as the <code>script</code>.

           
           </div>
         
           <table id="tb_problems_" class="data static">
                      <tbody><tr>
             <td>         <span class="err_type"><img id="msg_icon_1053_1_90" src="https://achecker.ca/images/error.png" alt="Error" title="Error" width="15" height="15"></span>
         <em>Line 1053, Column 1</em>:
         <pre><code class="input">&lt;script type="text/javascript"&gt;     var _gaq = _gaq || [];     _gaq.push(['_setAccount', 'UA-2824347 ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_1066_1_90" src="https://achecker.ca/images/error.png" alt="Error" title="Error" width="15" height="15"></span>
         <em>Line 1066, Column 1</em>:
         <pre><code class="input">&lt;script type="text/javascript"&gt;
/*
*/



&lt;/script&gt;</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>

           
           </tbody></table>
         </div>
	</div>

	<div id="AC_likely_problems" style="display:none;">
	<br>
	<span id="AC_congrats_msg_for_likely">
	</span>
<h3>Requirement 3: Text Equivalents</h3><br>
        <div class="gd_one_check"> 
           <span class="gd_msg">Check 4: 
              <a href="https://achecker.ca/checker/suggestion.php?id=4" onclick="AChecker.popup('https://achecker.ca/checker/suggestion.php?id=4'); return false;" target="_new">Image has suspicious Alt text (empty string "").</a>
           </span>

           <div class="gd_question_section">
           
           
           </div>
         
           <table id="tb_problems_" class="data static">
                      <tbody><tr>
             <td>         <span class="err_type"><img id="msg_icon_439_6_4" src="https://achecker.ca/images/warning.png" alt="Warning: Confirmation Required" title="Warning: Confirmation Required" width="15" height="15"></span>
         <em>Line 439, Column 6</em>:
         <pre><code class="input">&lt;img src="http://www.arpa.veneto.it/logo_arpav.gif" alt="" title="" height="53" width="504" /&gt;</code></pre>
         <img src="http://www.arpa.veneto.it/logo_arpav.gif" height="50" border="1" alt="">

         <p class="helpwanted">
         </p>
         
</td>
           </tr>

           
           </tbody></table>
         </div>
<h3>Requirement 15: Script/Object Alternatives</h3><br>
        <div class="gd_one_check"> 
           <span class="gd_msg">Check 94: 
              <a href="https://achecker.ca/checker/suggestion.php?id=94" onclick="AChecker.popup('https://achecker.ca/checker/suggestion.php?id=94'); return false;" target="_new">Content possibly not readable when stylesheets are removed (SCRIPT).</a>
           </span>

           <div class="gd_question_section">
           
           
           </div>
         
           <table id="tb_problems_" class="data static">
                      <tbody><tr>
             <td>         <span class="err_type"><img id="msg_icon_210_7_94" src="https://achecker.ca/images/warning.png" alt="Warning: Confirmation Required" title="Warning: Confirmation Required" width="15" height="15"></span>
         <em>Line 210, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_221_7_94" src="https://achecker.ca/images/warning.png" alt="Warning: Confirmation Required" title="Warning: Confirmation Required" width="15" height="15"></span>
         <em>Line 221, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_232_7_94" src="https://achecker.ca/images/warning.png" alt="Warning: Confirmation Required" title="Warning: Confirmation Required" width="15" height="15"></span>
         <em>Line 232, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_243_7_94" src="https://achecker.ca/images/warning.png" alt="Warning: Confirmation Required" title="Warning: Confirmation Required" width="15" height="15"></span>
         <em>Line 243, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_254_7_94" src="https://achecker.ca/images/warning.png" alt="Warning: Confirmation Required" title="Warning: Confirmation Required" width="15" height="15"></span>
         <em>Line 254, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_266_7_94" src="https://achecker.ca/images/warning.png" alt="Warning: Confirmation Required" title="Warning: Confirmation Required" width="15" height="15"></span>
         <em>Line 266, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"&gt;
/* - ploneglossary_definitions.js - */
// http://www.arpa.veneto.it/ ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_278_7_94" src="https://achecker.ca/images/warning.png" alt="Warning: Confirmation Required" title="Warning: Confirmation Required" width="15" height="15"></span>
         <em>Line 278, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_289_7_94" src="https://achecker.ca/images/warning.png" alt="Warning: Confirmation Required" title="Warning: Confirmation Required" width="15" height="15"></span>
         <em>Line 289, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_300_7_94" src="https://achecker.ca/images/warning.png" alt="Warning: Confirmation Required" title="Warning: Confirmation Required" width="15" height="15"></span>
         <em>Line 300, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_311_7_94" src="https://achecker.ca/images/warning.png" alt="Warning: Confirmation Required" title="Warning: Confirmation Required" width="15" height="15"></span>
         <em>Line 311, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_322_7_94" src="https://achecker.ca/images/warning.png" alt="Warning: Confirmation Required" title="Warning: Confirmation Required" width="15" height="15"></span>
         <em>Line 322, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_1053_1_94" src="https://achecker.ca/images/warning.png" alt="Warning: Confirmation Required" title="Warning: Confirmation Required" width="15" height="15"></span>
         <em>Line 1053, Column 1</em>:
         <pre><code class="input">&lt;script type="text/javascript"&gt;     var _gaq = _gaq || [];     _gaq.push(['_setAccount', 'UA-2824347 ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_1066_1_94" src="https://achecker.ca/images/warning.png" alt="Warning: Confirmation Required" title="Warning: Confirmation Required" width="15" height="15"></span>
         <em>Line 1066, Column 1</em>:
         <pre><code class="input">&lt;script type="text/javascript"&gt;
/*
*/



&lt;/script&gt;</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>

           
           </tbody></table>
         </div>
	</div>

	<div id="AC_potential_problems" style="margin-top:1em; display:none;">
	<br>
	<span id="AC_congrats_msg_for_potential">
	</span>
<h3>Requirement 3: Text Equivalents</h3><br>
        <div class="gd_one_check"> 
           <span class="gd_msg">Check 11: 
              <a href="https://achecker.ca/checker/suggestion.php?id=11" onclick="AChecker.popup('https://achecker.ca/checker/suggestion.php?id=11'); return false;" target="_new">Image may contain text that is not in Alt text.</a>
           </span>

           <div class="gd_question_section">
           
           
           </div>
         
           <table id="tb_problems_" class="data static">
                      <tbody><tr>
             <td>         <span class="err_type"><img id="msg_icon_439_6_11" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 439, Column 6</em>:
         <pre><code class="input">&lt;img src="http://www.arpa.veneto.it/logo_arpav.gif" alt="" title="" height="53" width="504" /&gt;</code></pre>
         <img src="http://www.arpa.veneto.it/logo_arpav.gif" height="50" border="1" alt="">

         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_444_3_11" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 444, Column 3</em>:
         <pre><code class="input">&lt;img src="logo_SNPA.png" alt="Logo SNPA" height="82px" style="position:relative;top:2px" /&gt;</code></pre>
         <img src="http://www.arpa.veneto.it/servizi-ambientali/acquisti-pubblici-verdi-gpp/acquisti-pubblici-verdi-gpp/logo_SNPA.png" height="50" border="1" alt="Logo SNPA">

         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_922_13_11" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 922, Column 13</em>:
         <pre><code class="input">&lt;img src="http://www.arpa.veneto.it/ico_print.gif "
                 alt="Stampa" title="Stampa" /&gt;</code></pre>
         <img src="http://www.arpa.veneto.it/ico_print.gif " height="50" border="1" alt="Stampa">

         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_1076_23_11" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 1076, Column 23</em>:
         <pre><code class="input">&lt;img alt=""
                           src="http://www.arpa.veneto.it/spinner.gif" /&gt;</code></pre>
         <img src="http://www.arpa.veneto.it/spinner.gif" height="50" border="1" alt="">

         <p class="helpwanted">
         </p>
         
</td>
           </tr>

           
           </tbody></table>
         </div>
        <div class="gd_one_check"> 
           <span class="gd_msg">Check 16: 
              <a href="https://achecker.ca/checker/suggestion.php?id=16" onclick="AChecker.popup('https://achecker.ca/checker/suggestion.php?id=16'); return false;" target="_new">Alt text is not empty and image may be decorative.</a>
           </span>

           <div class="gd_question_section">
           
           
           </div>
         
           <table id="tb_problems_" class="data static">
                      <tbody><tr>
             <td>         <span class="err_type"><img id="msg_icon_444_3_16" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 444, Column 3</em>:
         <pre><code class="input">&lt;img src="logo_SNPA.png" alt="Logo SNPA" height="82px" style="position:relative;top:2px" /&gt;</code></pre>
         <img src="http://www.arpa.veneto.it/servizi-ambientali/acquisti-pubblici-verdi-gpp/acquisti-pubblici-verdi-gpp/logo_SNPA.png" height="50" border="1" alt="Logo SNPA">

         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_922_13_16" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 922, Column 13</em>:
         <pre><code class="input">&lt;img src="http://www.arpa.veneto.it/ico_print.gif "
                 alt="Stampa" title="Stampa" /&gt;</code></pre>
         <img src="http://www.arpa.veneto.it/ico_print.gif " height="50" border="1" alt="Stampa">

         <p class="helpwanted">
         </p>
         
</td>
           </tr>

           
           </tbody></table>
         </div>
        <div class="gd_one_check"> 
           <span class="gd_msg">Check 178: 
              <a href="https://achecker.ca/checker/suggestion.php?id=178" onclick="AChecker.popup('https://achecker.ca/checker/suggestion.php?id=178'); return false;" target="_new">Alt text does not convey the same information as the image.</a>
           </span>

           <div class="gd_question_section">
           
           
           </div>
         
           <table id="tb_problems_" class="data static">
                      <tbody><tr>
             <td>         <span class="err_type"><img id="msg_icon_1076_23_178" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 1076, Column 23</em>:
         <pre><code class="input">&lt;img alt=""
                           src="http://www.arpa.veneto.it/spinner.gif" /&gt;</code></pre>
         <img src="http://www.arpa.veneto.it/spinner.gif" height="50" border="1" alt="">

         <p class="helpwanted">
         </p>
         
</td>
           </tr>

           
           </tbody></table>
         </div>
<h3>Requirement 4: Color Specific</h3><br>
        <div class="gd_one_check"> 
           <span class="gd_msg">Check 14: 
              <a href="https://achecker.ca/checker/suggestion.php?id=14" onclick="AChecker.popup('https://achecker.ca/checker/suggestion.php?id=14'); return false;" target="_new">Image may be using color alone.</a>
           </span>

           <div class="gd_question_section">
           
           
           </div>
         
           <table id="tb_problems_" class="data static">
                      <tbody><tr>
             <td>         <span class="err_type"><img id="msg_icon_922_13_14" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 922, Column 13</em>:
         <pre><code class="input">&lt;img src="http://www.arpa.veneto.it/ico_print.gif "
                 alt="Stampa" title="Stampa" /&gt;</code></pre>
         <img src="http://www.arpa.veneto.it/ico_print.gif " height="50" border="1" alt="Stampa">

         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_1076_23_14" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 1076, Column 23</em>:
         <pre><code class="input">&lt;img alt=""
                           src="http://www.arpa.veneto.it/spinner.gif" /&gt;</code></pre>
         <img src="http://www.arpa.veneto.it/spinner.gif" height="50" border="1" alt="">

         <p class="helpwanted">
         </p>
         
</td>
           </tr>

           
           </tbody></table>
         </div>
        <div class="gd_one_check"> 
           <span class="gd_msg">Check 55: 
              <a href="https://achecker.ca/checker/suggestion.php?id=55" onclick="AChecker.popup('https://achecker.ca/checker/suggestion.php?id=55'); return false;" target="_new"><code>input</code> possibly using color alone.</a>
           </span>

           <div class="gd_question_section">
           
           
           </div>
         
           <table id="tb_problems_" class="data static">
                      <tbody><tr>
             <td>         <span class="err_type"><img id="msg_icon_458_10_55" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 458, Column 10</em>:
         <pre><code class="input">&lt;input name="SearchableText" type="text"
                title="Cerca nel sito" accesskey="4"
       ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_463_9_55" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 463, Column 9</em>:
         <pre><code class="input">&lt;input class="searchButton" type="submit"
               value="Cerca" /&gt;</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_469_13_55" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 469, Column 13</em>:
         <pre><code class="input">&lt;input id="searchbox_currentfolder_only"
                   class="noborder" type="checkbox"
        ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>

           
           </tbody></table>
         </div>
        <div class="gd_one_check"> 
           <span class="gd_msg">Check 86: 
              <a href="https://achecker.ca/checker/suggestion.php?id=86" onclick="AChecker.popup('https://achecker.ca/checker/suggestion.php?id=86'); return false;" target="_new"><code>script</code> may use color alone.</a>
           </span>

           <div class="gd_question_section">
           
           
           </div>
         
           <table id="tb_problems_" class="data static">
                      <tbody><tr>
             <td>         <span class="err_type"><img id="msg_icon_210_7_86" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 210, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_221_7_86" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 221, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_232_7_86" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 232, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_243_7_86" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 243, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_254_7_86" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 254, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_266_7_86" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 266, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"&gt;
/* - ploneglossary_definitions.js - */
// http://www.arpa.veneto.it/ ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_278_7_86" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 278, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_289_7_86" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 289, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_300_7_86" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 300, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_311_7_86" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 311, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_322_7_86" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 322, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_1053_1_86" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 1053, Column 1</em>:
         <pre><code class="input">&lt;script type="text/javascript"&gt;     var _gaq = _gaq || [];     _gaq.push(['_setAccount', 'UA-2824347 ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_1066_1_86" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 1066, Column 1</em>:
         <pre><code class="input">&lt;script type="text/javascript"&gt;
/*
*/



&lt;/script&gt;</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>

           
           </tbody></table>
         </div>
<h3>Requirement 5: Flicker</h3><br>
        <div class="gd_one_check"> 
           <span class="gd_msg">Check 10: 
              <a href="https://achecker.ca/checker/suggestion.php?id=10" onclick="AChecker.popup('https://achecker.ca/checker/suggestion.php?id=10'); return false;" target="_new">Image (GIF) may flicker.</a>
           </span>

           <div class="gd_question_section">
           
           
           </div>
         
           <table id="tb_problems_" class="data static">
                      <tbody><tr>
             <td>         <span class="err_type"><img id="msg_icon_439_6_10" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 439, Column 6</em>:
         <pre><code class="input">&lt;img src="http://www.arpa.veneto.it/logo_arpav.gif" alt="" title="" height="53" width="504" /&gt;</code></pre>
         <img src="http://www.arpa.veneto.it/logo_arpav.gif" height="50" border="1" alt="">

         <p class="helpwanted">
         </p>
         
</td>
           </tr>

           
           </tbody></table>
         </div>
        <div class="gd_one_check"> 
           <span class="gd_msg">Check 87: 
              <a href="https://achecker.ca/checker/suggestion.php?id=87" onclick="AChecker.popup('https://achecker.ca/checker/suggestion.php?id=87'); return false;" target="_new"><code>script</code> may cause screen flicker.</a>
           </span>

           <div class="gd_question_section">
           
           
           </div>
         
           <table id="tb_problems_" class="data static">
                      <tbody><tr>
             <td>         <span class="err_type"><img id="msg_icon_210_7_87" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 210, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_221_7_87" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 221, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_232_7_87" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 232, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_243_7_87" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 243, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_254_7_87" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 254, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_266_7_87" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 266, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"&gt;
/* - ploneglossary_definitions.js - */
// http://www.arpa.veneto.it/ ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_278_7_87" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 278, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_289_7_87" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 289, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_300_7_87" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 300, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_311_7_87" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 311, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_322_7_87" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 322, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_1053_1_87" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 1053, Column 1</em>:
         <pre><code class="input">&lt;script type="text/javascript"&gt;     var _gaq = _gaq || [];     _gaq.push(['_setAccount', 'UA-2824347 ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_1066_1_87" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 1066, Column 1</em>:
         <pre><code class="input">&lt;script type="text/javascript"&gt;
/*
*/



&lt;/script&gt;</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>

           
           </tbody></table>
         </div>
<h3>Requirement 9: Data Table Header Elements</h3><br>
        <div class="gd_one_check"> 
           <span class="gd_msg">Check 136: 
              <a href="https://achecker.ca/checker/suggestion.php?id=136" onclick="AChecker.popup('https://achecker.ca/checker/suggestion.php?id=136'); return false;" target="_new">Data <code>table</code> may require <code>th</code> elements.</a>
           </span>

           <div class="gd_question_section">
           
           
           </div>
         
           <table id="tb_problems_" class="data static">
                      <tbody><tr>
             <td>         <span class="err_type"><img id="msg_icon_656_7_136" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 656, Column 7</em>:
         <pre><code class="input">&lt;table id="portal-columns"&gt;
        &lt;tbody&gt;
          &lt;tr&gt;
            
            &lt;td id="portal-c ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>

           
           </tbody></table>
         </div>
<h3>Requirement 13: Layout Table Linearize And Markup</h3><br>
        <div class="gd_one_check"> 
           <span class="gd_msg">Check 133: 
              <a href="https://achecker.ca/checker/suggestion.php?id=133" onclick="AChecker.popup('https://achecker.ca/checker/suggestion.php?id=133'); return false;" target="_new">Layout <code>table</code> may not linearize.</a>
           </span>

           <div class="gd_question_section">
           
           
           </div>
         
           <table id="tb_problems_" class="data static">
                      <tbody><tr>
             <td>         <span class="err_type"><img id="msg_icon_656_7_133" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 656, Column 7</em>:
         <pre><code class="input">&lt;table id="portal-columns"&gt;
        &lt;tbody&gt;
          &lt;tr&gt;
            
            &lt;td id="portal-c ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>

           
           </tbody></table>
         </div>
<h3>Requirement 14: Form Labels</h3><br>
        <div class="gd_one_check"> 
           <span class="gd_msg">Check 123: 
              <a href="https://achecker.ca/checker/suggestion.php?id=123" onclick="AChecker.popup('https://achecker.ca/checker/suggestion.php?id=123'); return false;" target="_new"><code>input</code> element <code>label</code>, <code>type</code> of "checkbox" is not positioned close to control.</a>
           </span>

           <div class="gd_question_section">
           
           
           </div>
         
           <table id="tb_problems_" class="data static">
                      <tbody><tr>
             <td>         <span class="err_type"><img id="msg_icon_469_13_123" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 469, Column 13</em>:
         <pre><code class="input">&lt;input id="searchbox_currentfolder_only"
                   class="noborder" type="checkbox"
        ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>

           
           </tbody></table>
         </div>
<h3>Requirement 15: Script/Object Alternatives</h3><br>
        <div class="gd_one_check"> 
           <span class="gd_msg">Check 88: 
              <a href="https://achecker.ca/checker/suggestion.php?id=88" onclick="AChecker.popup('https://achecker.ca/checker/suggestion.php?id=88'); return false;" target="_new">Content may not be accessible when <code>script</code> is disabled.</a>
           </span>

           <div class="gd_question_section">
           
           
           </div>
         
           <table id="tb_problems_" class="data static">
                      <tbody><tr>
             <td>         <span class="err_type"><img id="msg_icon_210_7_88" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 210, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_221_7_88" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 221, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_232_7_88" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 232, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_243_7_88" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 243, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_254_7_88" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 254, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_266_7_88" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 266, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"&gt;
/* - ploneglossary_definitions.js - */
// http://www.arpa.veneto.it/ ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_278_7_88" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 278, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_289_7_88" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 289, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_300_7_88" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 300, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_311_7_88" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 311, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_322_7_88" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 322, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_1053_1_88" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 1053, Column 1</em>:
         <pre><code class="input">&lt;script type="text/javascript"&gt;     var _gaq = _gaq || [];     _gaq.push(['_setAccount', 'UA-2824347 ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_1066_1_88" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 1066, Column 1</em>:
         <pre><code class="input">&lt;script type="text/javascript"&gt;
/*
*/



&lt;/script&gt;</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>

           
           </tbody></table>
         </div>
<h3>Requirement 16: Script/Object Accessible</h3><br>
        <div class="gd_one_check"> 
           <span class="gd_msg">Check 89: 
              <a href="https://achecker.ca/checker/suggestion.php?id=89" onclick="AChecker.popup('https://achecker.ca/checker/suggestion.php?id=89'); return false;" target="_new"><code>script</code> user interface may not be accessible.</a>
           </span>

           <div class="gd_question_section">
           
           
           </div>
         
           <table id="tb_problems_" class="data static">
                      <tbody><tr>
             <td>         <span class="err_type"><img id="msg_icon_210_7_89" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 210, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_221_7_89" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 221, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_232_7_89" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 232, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_243_7_89" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 243, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_254_7_89" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 254, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_266_7_89" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 266, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"&gt;
/* - ploneglossary_definitions.js - */
// http://www.arpa.veneto.it/ ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_278_7_89" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 278, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_289_7_89" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 289, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_300_7_89" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 300, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_311_7_89" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 311, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_322_7_89" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 322, Column 7</em>:
         <pre><code class="input">&lt;script type="text/javascript"
              src="http://www.arpa.veneto.it/portal_javascripts/arpav ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_1053_1_89" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 1053, Column 1</em>:
         <pre><code class="input">&lt;script type="text/javascript"&gt;     var _gaq = _gaq || [];     _gaq.push(['_setAccount', 'UA-2824347 ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_1066_1_89" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 1066, Column 1</em>:
         <pre><code class="input">&lt;script type="text/javascript"&gt;
/*
*/



&lt;/script&gt;</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>

           
           </tbody></table>
         </div>
<h3>Requirement 19: Link Text</h3><br>
        <div class="gd_one_check"> 
           <span class="gd_msg">Check 191: 
              <a href="https://achecker.ca/checker/suggestion.php?id=191" onclick="AChecker.popup('https://achecker.ca/checker/suggestion.php?id=191'); return false;" target="_new">Anchor's <code>title</code> may not describe the link destination.</a>
           </span>

           <div class="gd_question_section">
           
           
           </div>
         
           <table id="tb_problems_" class="data static">
                      <tbody><tr>
             <td>         <span class="err_type"><img id="msg_icon_443_2_191" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 443, Column 2</em>:
         <pre><code class="input">&lt;a style="float:left" href="http://www.snpambiente.it/" title="Sistema nazionale protezione ambiente ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_492_77_191" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 492, Column 77</em>:
         <pre><code class="input">&lt;a
    href="http://www.arpa.veneto.it/arpav" title=""&gt;
            &lt;span&gt;ARPAV&lt;/span&gt;
            &lt; ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_496_87_191" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 496, Column 87</em>:
         <pre><code class="input">&lt;a
    href="http://www.arpa.veneto.it/temi-ambientali"
    title=""&gt;
            &lt;span&gt;Temi Ambient ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_502_59_191" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 502, Column 59</em>:
         <pre><code class="input">&lt;a
    href="http://www.arpa.veneto.it/servizi-ambientali"
    title=""&gt;
            &lt;span&gt;Servizi A ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_507_85_191" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 507, Column 85</em>:
         <pre><code class="input">&lt;a
    href="http://www.arpa.veneto.it/arpavinforma" title=""&gt;
            &lt;span&gt;ARPAV informa&lt;/span ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_511_86_191" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 511, Column 86</em>:
         <pre><code class="input">&lt;a
    href="http://www.arpa.veneto.it/servizi-online" title=""&gt;
            &lt;span&gt;Servizi online&lt;/s ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_515_91_191" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 515, Column 91</em>:
         <pre><code class="input">&lt;a
    href="http://www.arpa.veneto.it/dati-ambientali"
    title=""&gt;
            &lt;span&gt;Dati ambient ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_527_5_191" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 527, Column 5</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/acquisti-pubblici-verdi-gpp"
       title=""&gt;
 ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_535_5_191" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 535, Column 5</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/certificazioni-ambientali"
       title=""&gt;
	  ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_543_5_191" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 543, Column 5</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/comunicazione"
       title=""&gt;
	      			&lt;spa ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_551_5_191" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 551, Column 5</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/cooperazione"
       title=""&gt;
	      			&lt;span ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_560_5_191" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 560, Column 5</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/educazione-per-la-sostenibilita"
       title= ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_568_5_191" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 568, Column 5</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/grandi-opere"
       title=""&gt;
	      			&lt;span ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_576_5_191" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 576, Column 5</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/ippc"
       title="Controllo Ambientale Integ ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_584_5_191" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 584, Column 5</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/pronta-disponibilita"
       title=""&gt;
	       ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_592_5_191" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 592, Column 5</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/qualita"
       title=""&gt;
	      			&lt;span&gt;Qual ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_600_5_191" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 600, Column 5</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/rischio-industriale"
       title=""&gt;
	      	 ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_608_5_191" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 608, Column 5</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/sicurezza-impiantistica"
       title=""&gt;
	    ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_690_9_191" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 690, Column 9</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/acquisti-pubblici-verdi-gpp/pan"
           cl ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_738_9_191" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 738, Column 9</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/acquisti-pubblici-verdi-gpp/riferimenti/contat ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_757_9_191" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 757, Column 9</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/acquisti-pubblici-verdi-gpp/riferimenti/normat ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_776_9_191" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 776, Column 9</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/acquisti-pubblici-verdi-gpp/riferimenti/pubbli ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_795_9_191" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 795, Column 9</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/acquisti-pubblici-verdi-gpp/riferimenti/notizi ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_921_11_191" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 921, Column 11</em>:
         <pre><code class="input">&lt;a href="javascript:this.print();" title=""&gt;
            &lt;img src="http://www.arpa.veneto.it/ico_pri ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_1035_30_191" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 1035, Column 30</em>:
         <pre><code class="input">&lt;a
    href="http://www.arpa.veneto.it" accesskey=""
    title="Home"&gt;Home&lt;/a&gt;</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_1038_36_191" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 1038, Column 36</em>:
         <pre><code class="input">&lt;a
    href="http://www.arpa.veneto.it/note-legali"
    accesskey="" title="Note legali"&gt;Note legali ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_1041_33_191" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 1041, Column 33</em>:
         <pre><code class="input">&lt;a
    href="http://www.arpa.veneto.it/privacy" accesskey=""
    title="Privacy"&gt;Privacy&lt;/a&gt;</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_1044_33_191" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 1044, Column 33</em>:
         <pre><code class="input">&lt;a
    href="http://www.arpa.veneto.it/sitemap" accesskey="3"
    title="Mappa del sito"&gt;Mappa del s ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_1047_39_191" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 1047, Column 39</em>:
         <pre><code class="input">&lt;a
    href="http://www.arpa.veneto.it/accessibility-info"
    accesskey="0" title="Accessibilità"&gt; ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_1058_128_191" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 1058, Column 128</em>:
         <pre><code class="input">&lt;a href="/informativa-cookie" title=""&gt;informativa sull’uso dei cookie&lt;/a&gt;</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>

           
           </tbody></table>
         </div>
        <div class="gd_one_check"> 
           <span class="gd_msg">Check 197: 
              <a href="https://achecker.ca/checker/suggestion.php?id=197" onclick="AChecker.popup('https://achecker.ca/checker/suggestion.php?id=197'); return false;" target="_new">Anchor text may not identify the link destination.</a>
           </span>

           <div class="gd_question_section">
           
           
           </div>
         
           <table id="tb_problems_" class="data static">
                      <tbody><tr>
             <td>         <span class="err_type"><img id="msg_icon_411_13_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 411, Column 13</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/login_form"&gt;Area Riservata&lt;/a&gt;</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_422_26_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 422, Column 26</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it"&gt;Home&lt;/a&gt;</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_423_8_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 423, Column 8</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/arpav/contatti"&gt;Contatti&lt;/a&gt;</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_424_45_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 424, Column 45</em>:
         <pre><code class="input">&lt;a href="mailto:protocollo@pec.arpav.it"&gt;protocollo@pec.arpav.it&lt;/a&gt;</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_429_3_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 429, Column 3</em>:
         <pre><code class="input">&lt;a accesskey="2"
     href="http://www.arpa.veneto.it/servizi-ambientali/acquisti-pubblici-verdi-gpp ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_432_3_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 432, Column 3</em>:
         <pre><code class="input">&lt;a accesskey="6"
     href="http://www.arpa.veneto.it/servizi-ambientali/acquisti-pubblici-verdi-gpp ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_437_2_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 437, Column 2</em>:
         <pre><code class="input">&lt;a id="portal-logo" accesskey="1"
    href="http://www.arpa.veneto.it"&gt;
	    &lt;img src="http://www.ar ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_443_2_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 443, Column 2</em>:
         <pre><code class="input">&lt;a style="float:left" href="http://www.snpambiente.it/" title="Sistema nazionale protezione ambiente ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_482_9_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 482, Column 9</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/search_form"
           accesskey="5"&gt;Ricerca avanzata…&lt;/a&gt;</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_492_77_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 492, Column 77</em>:
         <pre><code class="input">&lt;a
    href="http://www.arpa.veneto.it/arpav" title=""&gt;
            &lt;span&gt;ARPAV&lt;/span&gt;
            &lt; ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_496_87_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 496, Column 87</em>:
         <pre><code class="input">&lt;a
    href="http://www.arpa.veneto.it/temi-ambientali"
    title=""&gt;
            &lt;span&gt;Temi Ambient ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_502_59_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 502, Column 59</em>:
         <pre><code class="input">&lt;a
    href="http://www.arpa.veneto.it/servizi-ambientali"
    title=""&gt;
            &lt;span&gt;Servizi A ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_507_85_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 507, Column 85</em>:
         <pre><code class="input">&lt;a
    href="http://www.arpa.veneto.it/arpavinforma" title=""&gt;
            &lt;span&gt;ARPAV informa&lt;/span ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_511_86_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 511, Column 86</em>:
         <pre><code class="input">&lt;a
    href="http://www.arpa.veneto.it/servizi-online" title=""&gt;
            &lt;span&gt;Servizi online&lt;/s ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_515_91_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 515, Column 91</em>:
         <pre><code class="input">&lt;a
    href="http://www.arpa.veneto.it/dati-ambientali"
    title=""&gt;
            &lt;span&gt;Dati ambient ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_527_5_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 527, Column 5</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/acquisti-pubblici-verdi-gpp"
       title=""&gt;
 ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_535_5_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 535, Column 5</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/certificazioni-ambientali"
       title=""&gt;
	  ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_543_5_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 543, Column 5</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/comunicazione"
       title=""&gt;
	      			&lt;spa ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_551_5_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 551, Column 5</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/cooperazione"
       title=""&gt;
	      			&lt;span ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_560_5_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 560, Column 5</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/educazione-per-la-sostenibilita"
       title= ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_568_5_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 568, Column 5</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/grandi-opere"
       title=""&gt;
	      			&lt;span ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_576_5_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 576, Column 5</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/ippc"
       title="Controllo Ambientale Integ ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_584_5_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 584, Column 5</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/pronta-disponibilita"
       title=""&gt;
	       ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_592_5_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 592, Column 5</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/qualita"
       title=""&gt;
	      			&lt;span&gt;Qual ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_600_5_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 600, Column 5</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/rischio-industriale"
       title=""&gt;
	      	 ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_608_5_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 608, Column 5</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/sicurezza-impiantistica"
       title=""&gt;
	    ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_627_5_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 627, Column 5</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it"&gt;Portale&lt;/a&gt;</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_634_13_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 634, Column 13</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali"&gt;Servizi ambientali&lt;/a&gt;</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_672_8_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 672, Column 8</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/acquisti-pubblici-verdi-gpp"
          class=" ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_690_9_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 690, Column 9</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/acquisti-pubblici-verdi-gpp/pan"
           cl ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_720_8_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 720, Column 8</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/acquisti-pubblici-verdi-gpp/riferimenti"
      ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_738_9_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 738, Column 9</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/acquisti-pubblici-verdi-gpp/riferimenti/contat ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_757_9_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 757, Column 9</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/acquisti-pubblici-verdi-gpp/riferimenti/normat ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_776_9_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 776, Column 9</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/acquisti-pubblici-verdi-gpp/riferimenti/pubbli ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_795_9_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 795, Column 9</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/acquisti-pubblici-verdi-gpp/riferimenti/notizi ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_921_11_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 921, Column 11</em>:
         <pre><code class="input">&lt;a href="javascript:this.print();" title=""&gt;
            &lt;img src="http://www.arpa.veneto.it/ico_pri ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_998_20_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 998, Column 20</em>:
         <pre><code class="input">&lt;a href="http://www.arpa.veneto.it/servizi-ambientali/acquisti-pubblici-verdi-gpp/giornata-di-formaz ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_998_305_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 998, Column 305</em>:
         <pre><code class="input">&lt;a class="internal-link" href="../temi-ambientali/rifiuti/riferimenti/documenti/corso-gpp" target="_ ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_1030_36_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 1030, Column 36</em>:
         <pre><code class="input">&lt;a href="/note-legali"&gt;&lt;font color="white"&gt;CC BY&lt;/font&gt;&lt;/a&gt;</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_1035_30_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 1035, Column 30</em>:
         <pre><code class="input">&lt;a
    href="http://www.arpa.veneto.it" accesskey=""
    title="Home"&gt;Home&lt;/a&gt;</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_1038_36_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 1038, Column 36</em>:
         <pre><code class="input">&lt;a
    href="http://www.arpa.veneto.it/note-legali"
    accesskey="" title="Note legali"&gt;Note legali ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_1041_33_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 1041, Column 33</em>:
         <pre><code class="input">&lt;a
    href="http://www.arpa.veneto.it/privacy" accesskey=""
    title="Privacy"&gt;Privacy&lt;/a&gt;</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_1044_33_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 1044, Column 33</em>:
         <pre><code class="input">&lt;a
    href="http://www.arpa.veneto.it/sitemap" accesskey="3"
    title="Mappa del sito"&gt;Mappa del s ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_1047_39_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 1047, Column 39</em>:
         <pre><code class="input">&lt;a
    href="http://www.arpa.veneto.it/accessibility-info"
    accesskey="0" title="Accessibilità"&gt; ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_1058_128_197" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 1058, Column 128</em>:
         <pre><code class="input">&lt;a href="/informativa-cookie" title=""&gt;informativa sull’uso dei cookie&lt;/a&gt;</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>

           
           </tbody></table>
         </div>
        <div class="gd_one_check"> 
           <span class="gd_msg">Check 28: 
              <a href="https://achecker.ca/checker/suggestion.php?id=28" onclick="AChecker.popup('https://achecker.ca/checker/suggestion.php?id=28'); return false;" target="_new">Document may be missing a "skip to content" link.</a>
           </span>

           <div class="gd_question_section">
           
           
           </div>
         
           <table id="tb_problems_" class="data static">
                      <tbody><tr>
             <td>         <span class="err_type"><img id="msg_icon_397_3_28" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 397, Column 3</em>:
         <pre><code class="input">&lt;body class="section-servizi-ambientali section-servizi-ambientali-acquisti-pubblici-verdi-gpp secti ...</code></pre>
         
         <p class="helpwanted">
         </p>
         
</td>
           </tr>

           
           </tbody></table>
         </div>
        <div class="gd_one_check"> 
           <span class="gd_msg">Check 15: 
              <a href="https://achecker.ca/checker/suggestion.php?id=15" onclick="AChecker.popup('https://achecker.ca/checker/suggestion.php?id=15'); return false;" target="_new">Alt text may not identify the link destination.</a>
           </span>

           <div class="gd_question_section">
           
           
           </div>
         
           <table id="tb_problems_" class="data static">
                      <tbody><tr>
             <td>         <span class="err_type"><img id="msg_icon_439_6_15" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 439, Column 6</em>:
         <pre><code class="input">&lt;img src="http://www.arpa.veneto.it/logo_arpav.gif" alt="" title="" height="53" width="504" /&gt;</code></pre>
         <img src="http://www.arpa.veneto.it/logo_arpav.gif" height="50" border="1" alt="">

         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_444_3_15" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 444, Column 3</em>:
         <pre><code class="input">&lt;img src="logo_SNPA.png" alt="Logo SNPA" height="82px" style="position:relative;top:2px" /&gt;</code></pre>
         <img src="http://www.arpa.veneto.it/servizi-ambientali/acquisti-pubblici-verdi-gpp/acquisti-pubblici-verdi-gpp/logo_SNPA.png" height="50" border="1" alt="Logo SNPA">

         <p class="helpwanted">
         </p>
         
</td>
           </tr>
           <tr>
             <td>         <span class="err_type"><img id="msg_icon_922_13_15" src="https://achecker.ca/images/info.png" alt="Manual Check Required" title="Manual Check Required" width="15" height="15"></span>
         <em>Line 922, Column 13</em>:
         <pre><code class="input">&lt;img src="http://www.arpa.veneto.it/ico_print.gif "
                 alt="Stampa" title="Stampa" /&gt;</code></pre>
         <img src="http://www.arpa.veneto.it/ico_print.gif " height="50" border="1" alt="Stampa">

         <p class="helpwanted">
         </p>
         
</td>
           </tr>

           
           </tbody></table>
         </div>
	</div>

	<div id="AC_html_validation_result" style="margin-top:1em; display:none;">
		<br><ol><li class="msg_err"><strong>Note: Results are provided by http://validator.w3.org/</strong></li></ol>
<ol id="error_loop">

  <li class="msg_err">
    <span class="err_type"><img src="images/error.png" width="15" height="15" alt="Error" title="Error"></span>
    
    <em>Line 443,
        Column 111</em>:
    <span class="msg">there is no attribute "target"</span>
    <pre><code class="input">…snpambiente.it/" title="Sistema nazionale protezione ambiente" target=<strong title="Position where error was detected.">"</strong>_blank"&gt;</code></pre>
        <p class="helpwanted">
      <a href="feedback.html?uri=http%3A%2F%2Fwww.arpa.veneto.it%2Fservizi-ambientali%2Facquisti-pubblici-verdi-gpp;errmsg_id=108#errormsg" title="Suggest improvements on this error message through our feedback channels">✉</a>
    </p>

    <div class="ve mid-108">
    <p>
      You have used the attribute named above in your document, but the
      document type you are using does not support that attribute for this
      element. This error is often caused by incorrect use of the "Strict"
      document type with a document that uses frames (e.g. you must use
      the "Transitional" document type to get the "target" attribute), or
      by using vendor proprietary extensions such as "marginheight" (this
      is usually fixed by using CSS to achieve the desired effect instead).
    </p>
    <p>
      This error may also result if the element itself is not supported in
      the document type you are using, as an undefined element will have no
      supported attributes; in this case, see the element-undefined error
      message for further information.
    </p>
    <p>
      How to fix: check the spelling and case of the element and attribute, 
      (Remember XHTML is all lower-case) and/or 
      check that they are both allowed in the chosen document type, and/or
      use CSS instead of this attribute. If you received this error when using the 
      &lt;embed&gt; element to incorporate flash media in a Web page, see the 
      <a href="docs/help.html#faq-flash">FAQ item on valid flash</a>.
    </p>
  </div>

  </li>

  <li class="msg_err">
    <span class="err_type"><img src="images/error.png" width="15" height="15" alt="Error" title="Error"></span>
    
    <em>Line 1030,
        Column 71</em>:
    <span class="msg">there is no attribute "color"</span>
    <pre><code class="input">… - &lt;a href="/note-legali"&gt;&lt;font color=<strong title="Position where error was detected.">"</strong>white"&gt;CC BY&lt;/font&gt;&lt;/a&gt; - P.IVA 0338270…</code></pre>
        <p class="helpwanted">
      <a href="feedback.html?uri=http%3A%2F%2Fwww.arpa.veneto.it%2Fservizi-ambientali%2Facquisti-pubblici-verdi-gpp;errmsg_id=108#errormsg" title="Suggest improvements on this error message through our feedback channels">✉</a>
    </p>

    <div class="ve mid-108">
    <p>
      You have used the attribute named above in your document, but the
      document type you are using does not support that attribute for this
      element. This error is often caused by incorrect use of the "Strict"
      document type with a document that uses frames (e.g. you must use
      the "Transitional" document type to get the "target" attribute), or
      by using vendor proprietary extensions such as "marginheight" (this
      is usually fixed by using CSS to achieve the desired effect instead).
    </p>
    <p>
      This error may also result if the element itself is not supported in
      the document type you are using, as an undefined element will have no
      supported attributes; in this case, see the element-undefined error
      message for further information.
    </p>
    <p>
      How to fix: check the spelling and case of the element and attribute, 
      (Remember XHTML is all lower-case) and/or 
      check that they are both allowed in the chosen document type, and/or
      use CSS instead of this attribute. If you received this error when using the 
      &lt;embed&gt; element to incorporate flash media in a Web page, see the 
      <a href="docs/help.html#faq-flash">FAQ item on valid flash</a>.
    </p>
  </div>

  </li>

  <li class="msg_err">
    <span class="err_type"><img src="images/error.png" width="15" height="15" alt="Error" title="Error"></span>
    
    <em>Line 1030,
        Column 78</em>:
    <span class="msg">element "font" undefined</span>
    <pre><code class="input">…ref="/note-legali"&gt;&lt;font color="white"<strong title="Position where error was detected.">&gt;</strong>CC BY&lt;/font&gt;&lt;/a&gt; - P.IVA 03382700288&lt;/p…</code></pre>
        <p class="helpwanted">
      <a href="feedback.html?uri=http%3A%2F%2Fwww.arpa.veneto.it%2Fservizi-ambientali%2Facquisti-pubblici-verdi-gpp;errmsg_id=76#errormsg" title="Suggest improvements on this error message through our feedback channels">✉</a>
    </p>

    <div class="ve mid-76">
    <p>
      You have used the element named above in your document, but the
      document type you are using does not define an element of that name.
      This error is often caused by:
    </p> 
    <ul>
      <li>incorrect use of the "Strict" document type with a document that 
      uses frames (e.g. you must use the "Frameset" document type to get 
      the "&lt;frameset&gt;" element),</li>
      <li>by using vendor proprietary extensions such as "&lt;spacer&gt;"
      or "&lt;marquee&gt;" (this is usually fixed by using CSS to achieve
      the desired effect instead).</li>
      <li>by using upper-case tags in XHTML (in XHTML attributes and elements
      must be all lower-case).</li>
    </ul>
  </div>

  </li>

  <li class="msg_err">
    <span class="err_type"><img src="images/error.png" width="15" height="15" alt="Error" title="Error"></span>
    
    <em>Line 1059,
        Column 39</em>:
    <span class="msg">required attribute "action" not specified</span>
    <pre><code class="input">    &lt;form id="tlspu_cookiepolicy_form"<strong title="Position where error was detected.">&gt;</strong></code></pre>
        <p class="helpwanted">
      <a href="feedback.html?uri=http%3A%2F%2Fwww.arpa.veneto.it%2Fservizi-ambientali%2Facquisti-pubblici-verdi-gpp;errmsg_id=127#errormsg" title="Suggest improvements on this error message through our feedback channels">✉</a>
    </p>

    <div class="ve mid-127">
    <p>
      The attribute given above is required for an element that you've used,
      but you have omitted it. For instance, in most HTML and XHTML document
      types the "type" attribute is required on the "script" element and the
      "alt" attribute is required for the "img" element.
    </p>
    <p>
      Typical values for <code>type</code> are 
      <code>type="text/css"</code> for <code>&lt;style&gt;</code>
      and <code>type="text/javascript"</code> for <code>&lt;script&gt;</code>.
    </p>
  </div>

  </li>

  <li class="msg_err">
    <span class="err_type"><img src="images/error.png" width="15" height="15" alt="Error" title="Error"></span>
    
    <em>Line 1062,
        Column 60</em>:
    <span class="msg">document type does not allow element "button" here; missing one of "p", "h1", "h2", "h3", "h4", "h5", "h6", "div", "pre", "address", "fieldset", "ins", "del" start-tag</span>
    <pre><code class="input">        &lt;button id="tlspu_cookiepolicy_button" value="hide"<strong title="Position where error was detected.">&gt;</strong>Ok&lt;/button&gt;</code></pre>
        <p class="helpwanted">
      <a href="feedback.html?uri=http%3A%2F%2Fwww.arpa.veneto.it%2Fservizi-ambientali%2Facquisti-pubblici-verdi-gpp;errmsg_id=65#errormsg" title="Suggest improvements on this error message through our feedback channels">✉</a>
    </p>

    <div class="ve mid-65">
    <p>
      The mentioned element is not allowed to appear in the context in which
      you've placed it; the other mentioned elements are the only ones that
      are both allowed there <em>and</em> can contain the element mentioned.
      This might mean that you need a containing element, or possibly that
      you've forgotten to close a previous element.
    </p>
    <p> 
      One possible cause for this message is that you have attempted to put a
      block-level element (such as "&lt;p&gt;" or "&lt;table&gt;") inside an
      inline element (such as "&lt;a&gt;", "&lt;span&gt;", or "&lt;font&gt;").
    </p>
  </div>

  </li>

</ol>	</div>
	
		<div id="AC_css_validation_result" style="margin-top:1em; display:none;">
		<br><ol><li class="msg_err">
 <strong>Note: Results are provided by http://jigsaw.w3.org/css-validator </strong>
 
<div class="error-section-all">
 <div class="error-section">
  <h4>
   URI :
   <a href="http://www.arpa.veneto.it/portal_css/arpav_theme/resourcejquery-cachekey7609.css">
    http://www.arpa.veneto.it/portal_css/arpav_theme/resourcejquery-cachekey7609.css
   </a>
  </h4>
  <table>
   <tbody>
    <tr class="error">
     <td class="linenumber" title="Line 461">
      461
     </td>
     <td class="codeContext">
      .ui-datepicker-cover
     </td>
     <td class="parse-error">
      Parse Error
      <span class="unrecognized">
       mask()
      </span>
     </td>
    </tr>
   </tbody>
  </table>
  <!--end of individual error section-->
 </div>
 <div class="error-section">
  <h4>
   URI :
   <a href="http://www.arpa.veneto.it/portal_css/arpav_theme/++resource++tcp_stylesheets/cookiepolicy.css">
    http://www.arpa.veneto.it/portal_css/arpav_theme/++resource++tcp_stylesheets/cookiepolicy.css
   </a>
  </h4>
  <table>
   <tbody>
    <tr class="error">
     <td class="linenumber" title="Line 10">
      10
     </td>
     <td class="codeContext">
      #viewlet-cookiepolicy
     </td>
     <td class="parse-error">
      Value Error :  background-image                                             The first argument to the
      <code>
       linear-gradient
      </code>
      function should be
      <code>
       to top
      </code>
      , not
      <code>
       top
      </code>
      <span class="skippedString">
       )
      </span>
     </td>
    </tr>
   </tbody>
  </table>
  <!--end of individual error section-->
 </div>
 <div class="error-section">
  <h4>
   URI :
   <a href="http://www.arpa.veneto.it/portal_css/arpav_theme/ploneglossary_popup-cachekey5199.css">
    http://www.arpa.veneto.it/portal_css/arpav_theme/ploneglossary_popup-cachekey5199.css
   </a>
  </h4>
  <table>
   <tbody>
    <tr class="error">
     <td class="linenumber" title="Line 345">
      345
     </td>
     <td class="nocontext">
     </td>
     <td class="parse-error">
      Parse Error
      <span class="unrecognized">
       [
----------------------------------*/
/* */
.ui-corner-tl]
      </span>
     </td>
    </tr>
    <tr class="error">
     <td class="linenumber" title="Line 355">
      355
     </td>
     <td class="nocontext">
     </td>
     <td class="parse-error">
      Parse Error
      <span class="unrecognized">
       /* *//
.ui-widget-overlay { background: #5c5c5c url(ui.datepicker/ui-bg_flat_50_5c5c5c_40x100.png) 50% 50% repeat-x; opacity: .80;filter:Alpha(Opacity=80); }
      </span>
     </td>
    </tr>
    <tr class="error">
     <td class="linenumber" title="Line 408">
      408
     </td>
     <td class="codeContext">
      .ui-datepicker-cover
     </td>
     <td class="parse-error">
      Parse Error
      <span class="unrecognized">
       mask()
      </span>
     </td>
    </tr>
    <tr class="error">
     <td class="linenumber" title="Line 415">
      415
     </td>
     <td class="nocontext">
     </td>
     <td class="parse-error">
      Parse Error
      <span class="skippedString">
       }
      </span>
     </td>
    </tr>
   </tbody>
  </table>
 </div>
</div>
 </li></ol></div>
<div id="Autism_result" class="autism" style="margin-top:1em; display:none;">
<br>
	<h3 style="padding-left:10px">Presence of auto-animated images</h3>
	<div class="gd_one_check">
	<table id="tb_problems_aut" class="data static">
	<tbody>

<tr class="error">
	<td>
		<span class="err_type"><img src="images/error.png" width="15" height="15" alt="Error" title="Error"></span> <em> Line 301: </em><pre><code class="input">&lt;img src=http://www.arpa.veneto.it/logo_arpav.gif</code></pre>
<img src="http://www.arpa.veneto.it/logo_arpav.gif" height="50" border="1"/>
		</td>
	</tr>

<tr class="error">
	<td>
		<span class="err_type"><img src="images/error.png" width="15" height="15" alt="Error" title="Error"></span> <em> Line 1015: </em><pre><code class="input">&lt;img src=http://www.arpa.veneto.it/ico_print.gif </code></pre>
<img src="http://www.arpa.veneto.it/ico_print.gif " height="50" border="1"/>
		</td>
	</tr>

<tr class="error">
	<td>
		<span class="err_type"><img src="images/error.png" width="15" height="15" alt="Error" title="Error"></span> <em> Line 1272: </em><pre><code class="input">&lt;img src=http://www.arpa.veneto.it/spinner.gif</code></pre>
<img src="http://www.arpa.veneto.it/spinner.gif" height="50" border="1"/>
		</td>
	</tr>
		<p hidden>addheregif</p>
</tbody>
	</table>
</div>
<style>
.w3-container:after,.w3-container:before {
	content:"";
	display:table;
	clear:both;
	padding:0.01em 16px;width: 50%;
}
.w3-light-grey {
	color:#000!important;
	background-color:#f1f1f1!important;width: 50%;
	}
.progress {
	color:#fff!important;
	background-color:#3aafab!important;
	display:inline-block;
	width:auto;
	text-align:center!important;
}
</style>
<br>
	<h3 style="padding-left:10px">Text readability</h3>
	<div class="gd_one_check">
	<table id="tb_problems_aut" class="data static">
	<tbody>
<br><div class="w3-container" style="padding-left:10px">
	<div class="w3-light-grey">
		<div class="progress" style="width:97.1%">97.10%</div>
	</div>
</div>		</tbody>
	</table>
</div>
<br>
	<h2 style="padding-left:10px">Text readability - details</h2>
		<div class=“row_colors” style="padding-left:10px;">
		<div class=“square” style="display: inline-block;background-color: #ffff00;">sentences fairly difficult to read</div>
		<div class=“square” style="display: inline-block;background-color: #ff9642;">sentences difficult to read</div>
		<div class=“square” style="display: inline-block;background-color: #ff5454;">sentences very difficult to read</div>
		</div><br>
<div class="gd_one_check">
	<table id="tb_problems_aut" class="data static">
	

<tr>
	<td style="white-space: nowrap;">
		<span class="err_type"><img id="msg_icon_24_3_94" src="images/warning.png" alt="Warning: Confirmation Required" title="Warning: Confirmation Required" width="15" height="15"></span> <em> Issue 1: </em></td><td><span style="background-color: #ff5454">Home Note legali Privacy Mappa del sito Accessibilità</span>
		</td>
	</tr><tr>
	<td style="white-space: nowrap;">
		<span class="err_type"><img id="msg_icon_24_3_94" src="images/warning.png" alt="Warning: Confirmation Required" title="Warning: Confirmation Required" width="15" height="15"></span> <em> Issue 2: </em></td><td><span style="background-color: #ff9642">Il GPP va oltre il semplice inserimento di criteri verdi nei bandi di gara per le forniture.</span>
		</td>
	</tr><p hidden>txtcmpl</p>
		
	</table>
</div>
<br>
	<h3 style="padding-left:10px">Color difficulties</h3>
	<div class="gd_one_check">
	<table id="tb_problems_aut" class="data static">
	<tbody>
<tr class="error">
			<td>
				<span class="err_type"><img id="msg_icon_24_3_94" src="images/warning.png" alt="Warning: Confirmation Required" title="Warning: Confirmation Required" width="15" height="15"></span> Issues: </td><td><span style="margin-right:10px">div: #9cca3c</span><div class="circle" style="background:#9cca3c;"></div> <span style="margin-right:10px">a: #9cca3c</span><div class="circle" style="background:#9cca3c;"></div>			</td>
</tr>		</tbody>
	</table>
</div>
<p hidden>addhere</p>
</div>
<div id="Summary_result" class="sum_autism" style="margin-top:1em; display:none;">
<p hidden>add_summary_here</p>
 <style>
 
 #ok {
 text-align: center;
 position: absolute;
   margin: auto;
   top: 0;
   right: 0;
   bottom: 0;
   left: 0;
   width: 50%;
   height: 50%;
 }
 
 #notok table {
   font-family: arial, sans-serif;
   border: 1px solid #ccc;
   border-collapse: collapse;
   margin: 0;
   padding: 0;
   width: 100%;
   table-layout: fixed;
 }
 
 #notok table tr{
   background-color: #f8f8f8;
   border: 1px solid #ddd;
   padding: .35em;
 }
 
 #notok table th{
   padding: .625em;
   text-align: center;
   border: 1px solid #dddddd;
   word-wrap:break-word
 }
 
 #notok table td{
   padding: .625em;
   text-align: left;
   border: 1px solid #dddddd;
   word-wrap:break-word
 }
 
 #notok td img{
     display: block;
     margin-left: auto;
     margin-right: auto;
 
 }
 
 #notok table th{
   font-size: .85em;
   letter-spacing: .1em;
   text-transform: uppercase;
 }
 
 
 .classok {
   padding: 20px;
 }
 
 .classnotok{
 	display: none;
 }
 
 .legendtable {
     width: 100%;
     padding: 10px;
     overflow: hidden;
 }
 
 .legendtable img {
     margin-right: 15px;
     float: left;
 }
 
 </style>
 
 <div id="ok">
 
 <h1> Congratulations! </h1>
 <p> The site at the provided url is accessible for people with ASD </p>
 
 </div>
 <div id="notok">
 
 <p> url: http://www.arpa.veneto.it/servizi-ambientali/acquisti-pubblici-verdi-gpp <p>
 <!--h2> Sorry! </h2-->
 <a target="_blank" href="thumb.png">
 <img id="thu" src="thumb.png" alt="" width="100" height="65">
 </a>
 <p> Something at the given url is not accessible for people with disabilities, expecially for people with ASD </p>
 
 <form style="padding: 10px;">
  <fieldset style="font-family: arial, sans-serif;">
   <legend>How to read the table</legend>
   <div class="legendtable">
    <img src="images/error.png" alt="redcross" height="32" width="32">
     <p>Stands for "critical issues found"</p>
 </div>
 
 <div class="legendtable">
    <img src="images/green_tick.png" alt="greentick" height="32" width="32">
     <p>Stands for "ok, critical issues not found"</p>
 </div>
  </fieldset>
 </form>
 
 <br><br>
 
 <table id="table_sum">
   <thead>
     <tr>
       <th scope="col">Issue</th>
       <th scope="col">Result</th>
       <th scope="col">Details</th>
     </tr>
   </thead>
   <tbody>
 
     <tr>
       <td>Text Difficulties</td>
 		<td> <img src="images/error.png" alt="TxtD" height="12" width="12"></td>
       <td></td>
     </tr>
 
     <tr>
       <td>Overall Text readability</td>
 		<td> <img src="images/error.png" alt="TxtC" height="12" width="12"></td>
 		<td>Readability reached: 97.10% </td>
     </tr>
 
     <tr>
       <td>Presence of text in images</td>
 		<td> <img src="images/green_tick.png" alt="Tinimg" height="12" width="12"></td>
 		<td></td>
     </tr>
 
      <tr>
       <td>Presence of animated images</td>
 		<td> <img src="images/error.png" alt="gifs" height="12" width="12"></td>
 		<td></td>
     </tr>
 
 
     <tr>
       <td>Color difficulties in page elements</td>
 		<td> <img src="images/error.png" alt="coldiff" height="12" width="12"></td>
 		<td>Color: <span style="margin-right:10px">div: #9cca3c</span><div class="circle" style="background:#9cca3c;"></div> <span style="margin-right:10px">a: #9cca3c</span><div class="circle" style="background:#9cca3c;"></div></td>
 	</tr>
 
 
   </tbody>
 </table>
 
 </div>
 
 <script>
         /* display del del giusto div */
         var container = document.querySelector("#table_sum");
         var divs1 = document.querySelector("#ok");
         var divs2 = document.querySelector("#notok");
         var trs = container.querySelectorAll('tr');
 
         /*conto dei td*/
         var x = 0;
         var table = document.querySelector("#table_sum");
         var tds = table.querySelectorAll('td');
 
 
         for (i = 0; i < tds.length; i++) {
             var img = tds[i].getElementsByTagName("img")[0];
         	if(tds[i].contains(img)==true)
             	x=x+1;
        }
 
         if(x>0)
         {
             divs1.setAttribute("class", "classnotok");
             divs2.style['padding-left'] = '10px';
             divs2.style['padding-right'] = '10px';
         }
         else
         {
         	divs2.setAttribute("class", "classnotok");
             divs1.style['padding-left'] = '10px';
             divs1.style['padding-right'] = '10px';
         }
 
 </script>
</div>
	</fieldset>

</div>


</section>
<footer> 
          <div class="footer">
              <div class="footer_1">
                  CREATED BY: Margherita Rossi 
              </div>              
          </div>
    </footer>
    <script>
      /* Number of problems or issues */
        var container = document.querySelector("#Autism_result");
        var trs = container.querySelectorAll('tr')
        var text = document.createTextNode(trs.length);
        var child = document.getElementById('Autism_num_of_errors');
        child.parentNode.insertBefore(text, child);
    </script>
        
</body>
</html>

