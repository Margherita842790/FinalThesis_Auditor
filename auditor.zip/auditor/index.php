<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<title>Auditor</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="autism ,free, open source, accessibility checker, accessibility reviewer, accessibility evaluator, accessibility evaluation, evaluate accessibility, test accessibility, review accessibility, STANCA." />
	<meta name="description" content="Web accessibility evalution tool to help developer/health operators/relatives ensure accessibility of a Web content to people with autism." />
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/ac_out_style.css">
        <link rel="stylesheet" href="css/navbar.css">
        <script src="js/jquery.js" type="text/javascript"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js">
        <script type="text/javascript" src="js/jquery.ajax-cross-origin.min.js"></script>
        <script src="js/checker.js" type="text/javascript"></script>
        <script src="js/done_js.js" type="text/javascript"></script>


<style>
.fixed {
  position: fixed;
  top:0; left:0;
  width: 100%;
}

</style>
<script>
    
    $(document).ready(function() {
  $(window).keydown(function(event){
    if(event.keyCode == 13) {
      event.preventDefault();
      return false;
    }
  });
  
});

function rm(){
alert();
//alert = function() {};
$.get("removefile.php");
}
</script>

</head>
<body class="Site" onload="srcFunction()">
    <header>
      <div class="home">
          <div id="colh_1" class="colh_1">

            <div class="home_1">
              <a href="index.php">
                <img src="images/logo_white2.png">
            </a>
          </div>
          <div class="home_sub_logo" id="home_sub_logo">webpage validator for autism</div>

          </div>


            <div id="colh_2" class="colh_2">
              <a href="help.php" target="_blank"> <img src="images/question-mar.png">  </a>
            </div>

<div id="colh_2" class="colh_2">
              <a href="index.php"> <img src="images/gohome.png">  </a>
            </div>


      </div>

  </header>
  
  
  <main class="Site-content" id="main">
      
      <div class="container" id="cont-form">
        <form action="welcome.php" method="post">
            <div class="row">
                <div class="col-25">
                    <label for="fname">Website url</label>
                </div>
                <div class="col-75">
                    <!--input type="url" name="site" placeholder="Enter the site to be validated" autocomplete="off"-->
                    <input type="text" name="site" placeholder="Enter the site to be validated" autocomplete="off"  pattern="?:http(s)?:\/\/)?[\w.]+(?:\.[\w\.]+)+[\w\.:/?[\]@!\$&'\(\)\*,;.]+" required>
                </div>
            </div>
            <div class="row">
                
                <div class="col-25">
                </div>
                <div class="col-75"><!--input id="nu" class="nu" type="submit" name="user_button" value="I'm a normal user"-->  <!--input id="prog" class="prog" type="submit" name="programmer_button" value="I'm a programmer"-->
                    <input type="radio" id="normal"  name="usprog" value="normal" required> I'm a normal user
                    <input type="radio" id="programmer"  name="usprog" value="prog"> I'm a programmer
                    <input type="submit" value="Validate">
                </div>
            </div>
        </form>
          <div style="display: none; text-align: center; position: absolute; margin: auto; top: 0; right: 0; bottom: 0; left: 0; width: 50%; height: 50%;" id="loading_div">
    <h1>Please wait</h1>
    <p style="display: none;" id="nus"> you have selected "I'm a normal user" </p>
    <p style="display: none;" id="prus"> you have selected "I'm a programmer" </p>
    <p> Processing the url. It may take a few minutes. </p>
    <img src="images/loader.gif" alt="loading" id="loader" style="width: 30%"/>
</div>
         
      </div>
      
  </main>
<script>
  $(function() {
  $("form").submit(function(e) {
    e.preventDefault(); // Prevent the default submission of the form
    var form = $(this);
    var url = form.attr('action'); // Extract the URL from the form

    // Show your loading information and hide the form
    $("#main").css("background-color", "#f9f9f9");
    $("#cont-form").css("background-color", "#f9f9f9");
    $("#loading_div").show();
    if($('input[name=usprog]:checked').val()  == 'normal')
    {
        $("#nus").show();
    }
    else
    {
        $("#prus").show();
    }
    $("form").hide();

    $.ajax({
           crossOrigin:true,
           type: "POST",
           url: url,
           data: form.serialize(), // Send the form information as 
           success: function(data) {
               var data_succ = data;
                //alert(data_succ);
                if(data_succ=="0"){window.location.href = "problem.php";}
                if(data_succ=="2") {window.location.href = "summary.php";}
                if(data_succ=="3") {window.location.href = "res.php";}
                if(data_succ == "404"){window.location.href="404.php";}
                rm();
		return false;
           },
           error: function() {
                window.location.href = "swrong.php";
                return false;
           }
    });
  });
});
    </script>
  
  
  <!-- La dimensione del footer varia a seconda di ciÃ che ci metto dentro -->
  <footer> 
      <div class="footer">
          <div class="footer_1">
              CREATED BY: Margherita Rossi 
          </div>              
      </div>
  </footer>
  
</body>
</html>

