$(function() {

    /*riordino div*/
       
    $('ul').each(function() {
        $(this).replaceWith($('<input type="checkbox" id="btn-menu" class="checkbox-toggle"><label for = "btn-menu"><span class="navicon"></span></label><nav class="menu" id="nav"><ul>' + this.innerHTML + '</ul></nav>'));
    });
    
   var field = document.getElementsByClassName("group_form");
   $(field).each(function() {
        $(this).replaceWith($('' + this.innerHTML + ''));
    });
    
   var legend = document.getElementsByClassName("group_form");
   $(legend).each(function() {
        $(this).replaceWith($('' + this.innerHTML + ''));
    });
    
    
    var nodea = document.querySelector('[title="Stanca Act(link opens in a new window)"]');
    $(nodea).each(function() {
        $(this).remove();
    });
    
      
   var h = document.getElementsByTagName("h3");
   h[0].remove();
   
   var field = document.getElementsByClassName("center");
   $(field).each(function() {
        $(this).replaceWith($('<div id="tit_out"><h2>Accessibility Review </h2></div><div class="center">' + this.innerHTML + '</div>'));
    });
    
    /* js navbar */
  
   var nav = document.getElementsByClassName("topnavlistcontainer");
   $(nav).each(function() {
        $(this).replaceWith($('<div class="topnavlistcontainer" id="thenav">' + this.innerHTML + '</div>'));
    });
      

   $('li a').click(function() {
       // e.preventDefault();
        $(this).addClass('active');

   });
   
   $('li a').click(function() {
        $($('li a').hasClass('active')).each(function() {
            if(document.getElementById('btn-menu').checked)
                document.getElementById('btn-menu').checked = false;
        }); 
    });
    
    /*tolgo i link che non mi interessano*/

    $('.gd_msg > a').each(function () { $(this).contents().unwrap(); });
    
    $('p > a').each(function () { $(this).contents().unwrap(); });

    $('p.helpwanted').each(function () { $(this).remove() });

    $('h3').each(function () { $(this).replaceWith($('<div id="h3s"> <h3>' + this.innerHTML + '</h3></div>')); });
    
    /*fisso in alto la barra quando scendo*/
    $(window).scroll(function(){
        var sticky = $('.topnavlistcontainer'),
        scroll = $(window).scrollTop();
        if (scroll >= 155)
        {
            sticky.addClass('fixed');
        }
        else {
            sticky.removeClass('fixed');
            headr.removeClass('fixed');
        }
    });   
   
 });


function srcFunction() {
    var img = document.getElementsByTagName("img");
    for (i = 0; i < img.length; i++)
    {
    	if(img[i].src == "https://achecker.ca/images/error.png")
           img[i].src = "images/error.png";
        if(img[i].src == "https://achecker.ca/images/warning.png")
            	img[i].src = "images/warning.png";
        if(img[i].src == "https://achecker.ca/images/info.png")
            	img[i].src = "images/info.png";
    }
    var h2_orig = document.getElementsByTagName("h2");
	var searchText = "Accessibility Review ";
	var found=0;

	for (var i = 0; i < h2_orig.length; i++) {
        if (h2_orig[i].textContent == searchText) {
            h2_orig[i].style.paddingLeft = "15px";
            h2_orig[i].style.paddingTop = "10px";
        }
    }

	var divhtm = document.getElementById("AC_html_validation_result");
    var spanemp = divhtm.getElementsByClassName("err_type");
    var spanemp2 = divhtm.getElementsByClassName("msg");
    for (i = 0; i < spanemp.length; i++){
    	t = spanemp[i].textContent;
        t2 = spanemp2[i].textContent;
      if(t=="" && t2=="")
      {

      	parentil = spanemp[i].parentElement;
        parentil.remove();

       }
    }

}


 

