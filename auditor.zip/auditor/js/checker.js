/************************************************************************/
/* Margherita Rossi                                                     */
/* This program is free software. You can redistribute it and/or        */
/* modify it under the terms of the GNU General Public License          */
/* as published by the Free Software Foundation.                        */
/************************************************************************/

var AChecker = AChecker || {};

(function ($) {

    /**
     * global string function of trim()
     */
    String.prototype.trim = function () {
        return this.replace(/^\s+|\s+$/g, "");
    };

    /**
     * Open up a 600*800 popup window
     */
    AChecker.popup = function (url) {
        var newwindow = window.open(url, 'popup', 'height=600, width=800, scrollbars=yes, resizable=yes');
        if (window.focus) {newwindow.focus();}
    };

    /**
     * Toggle the collapse/expand images, alt texts and titles associated with the link
     * @param objId
     */
    AChecker.toggleDiv = function (objId, toggleImgId) {
        var toc = $("#" + objId);
        if (!toc) {
            return;
        }

        var toggleImg = $("#" + toggleImgId);
        if (toc.is(":visible")) {
            toggleImg.attr("src", "images/arrow-closed.png");
            toggleImg.attr("alt", "Expand");
            toggleImg.attr("title", "Expand");
        } else {
            toggleImg.attr("src", "images/arrow-open.png");
            toggleImg.attr("alt", "Collapse");
            toggleImg.attr("title", "Collapse");
        }

        toc.slideToggle();
    };

    /**
     * Display and activate the selected tab div
     * @param divId: the id of the tab div to display
     *        divMapping: The mapping between the tab IDs and corresponding menu IDs.
     * @returns return false if divId does not exist. Otherwise, show divId and hide other divs in the array allDivIds 
     */
    AChecker.showDivOutof = function (divId, divMapping) {
        if (!$("#" + divId)) {
            return false;
        }

        for (var eachDivId in divMapping) {
            if (eachDivId === divId) {
                $("#" + divId).show();
                $("#" + divMapping[eachDivId].menuID).addClass("active");
            } else {
                $("#" + eachDivId).hide();
                $("#" + divMapping[eachDivId].menuID).removeClass("active");
            }
        }
    };

    /**
     * Covers the DIV (divID) with a dynamically-generated disabled look-and-feel div.
     * The disabled div has the same size of divID (the 1st parameter) and is appended
     * onto the parentDivID (the 2nd parameter).
     * and append it to the pa 
     * @param divID: the div to cover
     * @param parentDivID: the parent div of divID (1st parameter)
     */
	AChecker.disableDiv = function (divID, parentDivID) {
        var cDivs = [];

        var d = $("#" + parentDivID); // parent div to expand the disabled div
        var e = $("#" + divID);  // the dynamically generated disabled div

        var xPos = e.offsetLeft;
        var yPos = e.offsetTop;
        var oWidth = e.offsetWidth;    
        var oHeight = e.offsetHeight;
        cDivs[cDivs.length] = document.createElement("DIV");
        cDivs[cDivs.length - 1].style.width = oWidth + "px";
        cDivs[cDivs.length - 1].style.height = oHeight + "px";
        cDivs[cDivs.length - 1].style.position = "absolute";
        cDivs[cDivs.length - 1].style.left = xPos + "px";
        cDivs[cDivs.length - 1].style.top = yPos + "px";
        cDivs[cDivs.length - 1].style.backgroundColor = "#999999";
        cDivs[cDivs.length - 1].style.opacity = 0.6;
        cDivs[cDivs.length - 1].style.filter = "alpha(opacity=60)";
        d.appendChild(cDivs[cDivs.length - 1]);
    };
})(jQuery);


var AChecker = AChecker || {};
AChecker.utility = AChecker.utility || {};
AChecker.input = AChecker.input || {};
AChecker.output = AChecker.output || {};

(function ($) {
    // The mapping between the tab IDs and corresponding menu & spinner IDs on the validator input form
    var inputDivMapping = {
        "AC_by_uri": {
            menuID: "AC_menu_by_uri",
            spinnerID: "AC_spinner_by_uri"
        },
        "AC_by_upload": {
            menuID: "AC_menu_by_upload",
            spinnerID: "AC_spinner_by_upload"
        },
        "AC_by_paste": {
            menuID: "AC_menu_by_paste",
            spinnerID: "AC_spinner_by_paste"
        }
    };

    // The mapping between the tab IDs and their corresponding menu IDs on the validator output form
    var outputDivMapping = {
        "AC_errors": {
            menuID: "AC_menu_errors"
        },
        "AC_likely_problems": {
            menuID: "AC_menu_likely_problems" 
        },
        "AC_potential_problems": {
            menuID: "AC_menu_potential_problems"
        },
        "AC_html_validation_result": {
            menuID: "AC_menu_html_validation_result"
        },
        "AC_css_validation_result": {
            menuID: "AC_menu_css_validation_result"
        },
        "Autism_result":{
            menuID: "Autism_menu_errors"
        },
        "Summary_result":{
            menuID: "Summary_menu_errors"
        }
    };

    AChecker.output.makeDecisionButtonId = "AC_btn_make_decision_lineNumRpt";
    AChecker.output.sealDivID = "AC_seals_div";

    // Private variables that are only available in this script
    var disableClass = "AC_disabled";
    
    var clickOptionRptGDL = function () {
        $("#guideline_in_checkbox").hide();
        $("#guideline_in_radio").show();
    };
    
    var clickOptionRptLine = function () {
        $("#guideline_in_checkbox").show();
        $("#guideline_in_radio").hide();
    };
    
    /**
     * Display the clicked tab and show/hide "made decision" button according to the displayed tab.
     * @param tab: "validate_uri", "validate_file", "validate_paste"
     *        rptFormat: "by_guideline", "by_line"
     */
    AChecker.input.initialize = function (tab, rptFormat) {
        // initialize input form
        $("#" + inputDivMapping[tab].spinnerID).hide();
        
        AChecker.showDivOutof(tab, inputDivMapping);
        
        // initialize output form
        var div_errors_id = "AC_errors";
        var div_errors = document.getElementById(div_errors_id);

        if (div_errors) {
            // show tab "errors", hide other tabs
            AChecker.showDivOutof(div_errors_id, outputDivMapping);            

            // hide button "make decision" as tab "errors" are selected
            $("#" + AChecker.output.makeDecisionButtonId).hide();
        } else { // no output yet, set focus on "check by uri" input box
            document.getElementById("checkuri").focus();
        }
        
        // link click event on radio buttons on "options" => "report format"
        $("#option_rpt_gdl").click(clickOptionRptGDL);
        $("#option_rpt_line").click(clickOptionRptLine);
        
        // initialized the "options" => "guidelines" section, based on the selected "report format"
        if (rptFormat === "by_guideline") {
            $("#option_rpt_gdl").trigger("click");
        } else if (rptFormat === "by_line") {
            $("#option_rpt_line").trigger("click");
        }
    };
    
    /**
     * Display and activate the selected input div
     * @param divId: the id of the selected input div
     */
    AChecker.input.onClickTab = function (divId) {
        // check if the div is disabled
        if (!$('#' + inputDivMapping[divId].menuID).hasClass(disableClass)) {
            AChecker.showDivOutof(divId, inputDivMapping);
        }
        return false;
    };

    var disableClickablesAndShowSpinner = function (spinnerID) {
        // disable the tabs on the input form by adding css class "AC_disabled"
        // which is detected and processed in AChecker.input.onClickTab()
        for (var key in inputDivMapping) {
            $('#' + inputDivMapping[key].menuID).addClass(disableClass);
        }
        
        $("#" + spinnerID).show();
        document.getElementById(spinnerID).focus();
    };
    
    var enableClickablesAndHideSpinner = function (spinnerID) {
        for (var key in inputDivMapping) {
            $('#' + inputDivMapping[key].menuID).removeClass(disableClass);
        }
        
        $("#" + spinnerID).hide();
    };
    
    

    /**
     * Display and activate the selected output div
     * @param divId: the id of the selected output div
     */
    AChecker.output.onClickTab = function (divId) {
        window.location.hash = 'output_div';
        AChecker.showDivOutof(divId, outputDivMapping);

        if (divId === "AC_errors" || divId === "AC_html_validation_result" || divId === "AC_css_validation_result"|| divId === "Autism_result"|| divId === "Summary_result") {
            $("#" + AChecker.output.makeDecisionButtonId).hide();
        } else {
            $("#" + AChecker.output.makeDecisionButtonId).show();
        }
        
        return false;
    };
    
    
    
    
    
    
    /**
     * private
     * Modify the number of problems on the tab bar. 
     * Called by makeDecisions()
     */
    var changeNumOfProblems = function () {
        var divsToLookup = ["AC_likely_problems", "AC_potential_problems"];
        var divIDsToUpdateErrorNum = ["AC_num_of_likely", "AC_num_of_potential"];
        var arrayNumOfProblems = new Array(2);

        // decide the tab to work on and number of problems
        for (var i in divsToLookup) {
            var currentDiv = $('div[id="' + divsToLookup[i] + '"]');
            // find number of all problems (checkboxes) in the current tab
            var total = $(currentDiv).find("input[class=AC_childCheckBox]").length;
            var checked = $(currentDiv).find("input[class=AC_childCheckBox]:checked").length;
            
            var numOfProblems = total - checked;
            $("#" + divIDsToUpdateErrorNum[i]).html(numOfProblems);
            
            arrayNumOfProblems[i] = numOfProblems;
        }
        
        return arrayNumOfProblems;
    };
    
    /**
     * Click event on "make decision" buttons. It does:
     * 1. ajax post to save into db
     * 2. prompt success or error msg returned from server besides the "make decision" button
     * 3. flip warning/info icons besides problems with pass decisons made to green pass icons
     * 4. change the number of problems on the tab bar
     * 5. when the number of problems is reduced to 0, 
     *    ajax request the seal html from server and display it in seal container
     */
    var makeDecision = function (btn_make_decision) {
        var ajaxPostStr = "";

        $('input[class="AC_childCheckBox"]').each(function () {
            if (this.checked) {
                ajaxPostStr += $(this).attr('name') + "=" + "P" + "&";
            } else {
                ajaxPostStr += $(this).attr('name') + "=" + "N" + "&";
            }
        });

        ajaxPostStr += "uri" + "=" + $.URLEncode($('input[name="uri"]').attr('value')) + "&" + 
            "output" + "=" + $('input[name="output"]').attr('value') + "&" +
            "jsessionid" + "=" + $('input[name="jsessionid"]').attr('value');
    
        $.ajax({
            type: "POST",
            url: "checker/save_decisions.php",
            data: ajaxPostStr,

            success: function (data) {
                // display success message
                displaySuccessMsg(btn_make_decision, data);
                
                // flip icon to green pass icon
                flipMsgIcon(btn_make_decision);
                
                // modify and store the number of problems on the tab bar
                var arrayNumOfProblems = changeNumOfProblems();
                
                // No more likely problems, display congrats message on "likely problems" tab
                if (arrayNumOfProblems[0] === 0) {
                    $("#AC_congrats_msg_for_likely").html(AChecker.lang.congrats_likely);
                    $("#AC_congrats_msg_for_likely").addClass("congrats_msg");
                } else {
                    $("#AC_congrats_msg_for_likely").html("");
                    $("#AC_congrats_msg_for_likely").removeClass("congrats_msg");
                }
                
                // No more potential problems, display congrats message on "potential problems" tab
                if (arrayNumOfProblems[1] === 0) {
                    $("#AC_congrats_msg_for_potential").html(AChecker.lang.congrats_potential);
                    $("#AC_congrats_msg_for_potential").addClass("congrats_msg");
                } else {
                    $("#AC_congrats_msg_for_potential").html("");
                    $("#AC_congrats_msg_for_potential").removeClass("congrats_msg");
                }
                
                // if all errors, likely, potential problems are 0, retrieve seal
                if (arrayNumOfProblems[0] === 0 && arrayNumOfProblems[1] === 0) {
                    // find the number of errors
                    var numOfErrors = $('#AC_num_of_errors').text();

                    if (numOfErrors === 0) {
                        showSeal(btn_make_decision);
                    }
                } else {
                    $('#' + AChecker.output.sealDivID).html("");
                }
            }, 
            
            error: function (xhr, errorType, exception) {
                // display error message
                displayErrorMsg(btn_make_decision, $(xhr.responseText).text());
            }
        });
    };



 

    $(document).ready(
        function () {
             
            // clicking on "make decision" button
            $('input[id^="AC_btn_make_decision"]').click(function () {
                makeDecision(this);
            });
        
        }
    );
})(jQuery);