<?php

$path = "/var/www/html/auditor/dl.txt";
unlink($path);
?>
